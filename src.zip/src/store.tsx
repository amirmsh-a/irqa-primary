import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api } from './data';
import { arabicError } from './data/api';
import type { AppData, ClassRoom, Criterion, Profile, Subject, Teacher } from './lib/types';

interface Toast { id: number; kind: 'ok' | 'error' | 'info'; text: string }

interface Store {
  user: Profile | null;
  data: AppData | null;
  booting: boolean;
  setUser(u: Profile | null): void;
  reload(): Promise<void>;
  /** ينفّذ عملية حفظ ثم يعيد تحميل البيانات ويعرض رسالة نجاح أو خطأ بالعربية */
  run(action: () => Promise<void>, okText?: string): Promise<boolean>;
  toast(kind: Toast['kind'], text: string): void;
  toasts: Toast[];
  dismiss(id: number): void;
  theme: 'light' | 'dark';
  toggleTheme(): void;
  isStaff: boolean;
  isAdmin: boolean;
}

const Ctx = createContext<Store | null>(null);
export const useStore = () => {
  const s = useContext(Ctx);
  if (!s) throw new Error('store missing');
  return s;
};

/** بيانات جاهزة مع فهارس للبحث السريع. تُستخدم داخل الصفحات بعد التحميل */
export function useData() {
  const { data } = useStore();
  if (!data) throw new Error('data not loaded');
  return useMemo(() => {
    const teacher = new Map<string, Teacher>(data.teachers.map((t) => [t.id, t]));
    const subject = new Map<string, Subject>(data.subjects.map((s) => [s.id, s]));
    const klass = new Map<string, ClassRoom>(data.classes.map((c) => [c.id, c]));
    const criteria: Criterion[] = [...data.criteria].sort((a, b) => a.domain - b.domain || a.sort_order - b.sort_order);
    return {
      ...data, criteria,
      teacherName: (id: string | null) => (id && teacher.get(id)?.name) || '—',
      subjectName: (id: string | null) => (id && subject.get(id)?.name) || '—',
      className: (id: string | null) => (id && klass.get(id)?.name) || '—',
      teacherById: teacher,
    };
  }, [data]);
}

function initialTheme(): 'light' | 'dark' {
  try {
    const saved = localStorage.getItem('ziyarat.theme');
    if (saved === 'dark' || saved === 'light') return saved;
  } catch { /* تجاهل */ }
  return typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<Profile | null>(null);
  const [data, setData] = useState<AppData | null>(null);
  const [booting, setBooting] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>(initialTheme);
  const seq = useRef(0);

  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const toast = useCallback((kind: Toast['kind'], text: string) => {
    const id = ++seq.current;
    setToasts((t) => [...t.slice(-3), { id, kind, text }]);
    setTimeout(() => dismiss(id), kind === 'error' ? 7000 : 3500);
  }, [dismiss]);

  const reload = useCallback(async () => { setData(await api.loadAll()); }, []);

  const setUser = useCallback((u: Profile | null) => {
    setUserState(u);
    if (!u) setData(null);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try { localStorage.setItem('ziyarat.theme', theme); } catch { /* تجاهل */ }
  }, [theme]);

  useEffect(() => {
    (async () => {
      try {
        const u = await api.getSession();
        if (u) { setUserState(u); await reload(); }
      } catch (e) {
        toast('error', arabicError(e));
      } finally {
        setBooting(false);
      }
    })();
  }, [reload, toast]);

  const run = useCallback(async (action: () => Promise<void>, okText?: string) => {
    try {
      await action();
      await reload();
      if (okText) toast('ok', okText);
      return true;
    } catch (e) {
      toast('error', arabicError(e));
      return false;
    }
  }, [reload, toast]);

  const value: Store = {
    user, data, booting, setUser, reload, run, toast, toasts, dismiss, theme,
    toggleTheme: () => setTheme((t) => (t === 'dark' ? 'light' : 'dark')),
    isStaff: user?.role === 'admin' || user?.role === 'observer',
    isAdmin: user?.role === 'admin',
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
