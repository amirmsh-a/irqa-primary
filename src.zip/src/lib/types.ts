export type Role = 'admin' | 'observer' | 'teacher';

export interface Settings { school: string; year: string; observer: string }
export interface Subject { id: string; name: string; sort_order: number }
export interface ClassRoom { id: string; grade: string; section: string; name: string; sort_order: number }
export interface Teacher { id: string; name: string; subject_id: string | null; active: boolean }
export interface Criterion {
  id: string; domain: 1 | 2 | 3; sort_order: number; letter: string;
  title: string; description: string; weight: number;
}
/** درجة معيار داخل زيارة: الوزن محفوظ مع الزيارة حتى لا تتغير النتائج السابقة */
export interface VisitScore { criterion_id: string; score: number; weight: number }
export interface Visit {
  id: string; teacher_id: string; visit_number: 1 | 2; visit_date: string;
  subject_id: string | null; class_id: string | null; period: number | null;
  observer_name: string; observer_feedback: string; teacher_reflection: string;
  created_at?: string; scores: VisitScore[];
}
export interface ScheduleRow {
  teacher_id: string; specialty: string; status: 'في الموعد' | 'تعديل';
  v1_week: string; v1_date: string | null; v1_period: number | null; v1_class_id: string | null;
  v2_week: string; v2_date: string | null; v2_period: number | null; v2_class_id: string | null;
}
export interface Profile { id: string; email: string; full_name: string; role: Role; teacher_id: string | null }
export interface Invite { email: string; full_name: string; role: Role; teacher_id: string | null }

export interface AppData {
  settings: Settings; subjects: Subject[]; classes: ClassRoom[]; teachers: Teacher[];
  criteria: Criterion[]; visits: Visit[]; schedule: ScheduleRow[];
}

export const DOMAINS: { id: 1 | 2 | 3; name: string }[] = [
  { id: 1, name: 'الإدارة الصفية' },
  { id: 2, name: 'الممارسات التدريسية' },
  { id: 3, name: 'الملاحظة والتغذية الراجعة' },
];

export const SCALE = [
  { value: 0, label: 'غير مقبول' },
  { value: 1, label: 'غير ملاحظ' },
  { value: 2, label: 'متطور' },
  { value: 3, label: 'كفء' },
  { value: 4, label: 'نموذجي ومتميز' },
] as const;

export const WEEKS = ['الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر','الثالث عشر','الرابع عشر','الخامس عشر','السادس عشر','السابع عشر','الثامن عشر'];
export const PERIODS = [1, 2, 3, 4, 5, 6, 7];
