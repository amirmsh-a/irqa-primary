import JSZip from 'jszip';

/**
 * قارئ وكاتب مبسّط لملفات Excel (xlsx / xlsm) يكفي لسجل التقييم:
 * يقرأ القيم (نصوص وأرقام) ويكتب جداول منسقة مع دمج الخلايا واتجاه من اليمين لليسار.
 */
export type Cell = string | number | null;
export interface SheetData { name: string; rows: Cell[][] }

const colIndex = (ref: string) => {
  let n = 0;
  for (const ch of ref) {
    const c = ch.charCodeAt(0);
    if (c < 65 || c > 90) break;
    n = n * 26 + (c - 64);
  }
  return n - 1;
};
export const colName = (i: number) => {
  let s = '';
  for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
  return s;
};

const textOf = (el: Element | null | undefined) => {
  if (!el) return '';
  // نتجاهل النطق الصوتي rPh ونجمع كل عناصر t
  return [...el.getElementsByTagName('t')].filter((t) => t.parentElement?.tagName !== 'rPh').map((t) => t.textContent ?? '').join('');
};

export async function readWorkbook(file: ArrayBuffer): Promise<SheetData[]> {
  const zip = await JSZip.loadAsync(file);
  const xml = async (path: string) => {
    const f = zip.file(path);
    return f ? new DOMParser().parseFromString(await f.async('string'), 'application/xml') : null;
  };
  const wb = await xml('xl/workbook.xml');
  const rels = await xml('xl/_rels/workbook.xml.rels');
  if (!wb || !rels) throw new Error('الملف ليس مصنف Excel صالحاً');
  const target = new Map([...rels.getElementsByTagName('Relationship')].map((r) => [r.getAttribute('Id'), r.getAttribute('Target') ?? '']));
  const sst = await xml('xl/sharedStrings.xml');
  const strings = sst ? [...sst.getElementsByTagName('si')].map((si) => textOf(si)) : [];

  const out: SheetData[] = [];
  for (const s of [...wb.getElementsByTagName('sheet')]) {
    const rid = s.getAttribute('r:id') ?? s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
    let t = target.get(rid) ?? '';
    if (!/worksheets\//.test(t)) continue;
    t = t.startsWith('/') ? t.slice(1) : `xl/${t}`;
    const doc = await xml(t);
    if (!doc) continue;
    const rows: Cell[][] = [];
    for (const row of [...doc.getElementsByTagName('row')]) {
      const r = Number(row.getAttribute('r')) - 1;
      const cells: Cell[] = [];
      for (const c of [...row.getElementsByTagName('c')]) {
        const ci = colIndex(c.getAttribute('r') ?? 'A');
        const type = c.getAttribute('t');
        const v = c.getElementsByTagName('v')[0]?.textContent ?? '';
        let val: Cell = null;
        if (type === 's') val = strings[Number(v)] ?? '';
        else if (type === 'inlineStr') val = textOf(c.getElementsByTagName('is')[0]);
        else if (type === 'str' || type === 'e') val = v;
        else if (type === 'b') val = Number(v);
        else if (v !== '') val = Number(v);
        if (val !== null && val !== '') cells[ci] = val;
      }
      if (cells.length) rows[r] = cells;
    }
    out.push({ name: s.getAttribute('name') ?? '', rows });
  }
  return out;
}

// ---------------------------------------------------------------- الكتابة

export type Style = 'text' | 'head' | 'num' | 'date' | 'title' | 'total';
export interface OutCell { v: Cell; s?: Style }
export interface OutSheet {
  name: string;
  rows: (OutCell | Cell)[][];
  merges?: string[];
  widths?: number[];
  freeze?: { rows: number; cols: number };
}
const styleId: Record<Style, number> = { text: 1, head: 2, num: 3, date: 4, title: 5, total: 6 };
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="3"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font><font><b/><sz val="14"/><name val="Arial"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDBE9EC"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEEF3F4"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FF7A8A8E"/></left><right style="thin"><color rgb="FF7A8A8E"/></right><top style="thin"><color rgb="FF7A8A8E"/></top><bottom style="thin"><color rgb="FF7A8A8E"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1" readingOrder="2"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="14" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center" readingOrder="2"/></xf>
<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
</cellXfs>
</styleSheet>`;

function sheetXml(sh: OutSheet): string {
  const rows = sh.rows.map((row, r) => {
    if (!row) return '';
    const cells = row.map((cell, c) => {
      const oc: OutCell = cell !== null && typeof cell === 'object' ? cell : { v: cell };
      if (oc.v === null || oc.v === undefined || oc.v === '') {
        return oc.s ? `<c r="${colName(c)}${r + 1}" s="${styleId[oc.s]}"/>` : '';
      }
      const ref = `${colName(c)}${r + 1}`;
      if (typeof oc.v === 'number') return `<c r="${ref}" s="${styleId[oc.s ?? 'num']}"><v>${oc.v}</v></c>`;
      return `<c r="${ref}" s="${styleId[oc.s ?? 'text']}" t="inlineStr"><is><t xml:space="preserve">${esc(String(oc.v))}</t></is></c>`;
    }).join('');
    return cells ? `<row r="${r + 1}">${cells}</row>` : '';
  }).join('');
  const cols = sh.widths?.length ? `<cols>${sh.widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>` : '';
  const pane = sh.freeze
    ? `<pane xSplit="${sh.freeze.cols}" ySplit="${sh.freeze.rows}" topLeftCell="${colName(sh.freeze.cols)}${sh.freeze.rows + 1}" activePane="bottomRight" state="frozen"/>`
    : '';
  const merges = sh.merges?.length ? `<mergeCells count="${sh.merges.length}">${sh.merges.map((m) => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>` : '';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0">${pane}</sheetView></sheetViews><sheetFormatPr defaultRowHeight="18"/>${cols}<sheetData>${rows}</sheetData>${merges}</worksheet>`;
}

export async function writeWorkbook(sheets: OutSheet[]): Promise<Blob> {
  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
  zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
  zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s, i) => `<sheet name="${esc(s.name.slice(0, 31))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
  zip.file('xl/styles.xml', STYLES);
  sheets.forEach((s, i) => zip.file(`xl/worksheets/sheet${i + 1}.xml`, sheetXml(s)));
  return zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', compression: 'DEFLATE' });
}

/** رقم Excel التسلسلي لتاريخ YYYY-MM-DD */
export function excelDate(iso: string): number {
  const [y, m, d] = iso.split('-').map(Number);
  return Math.round(Date.UTC(y, m - 1, d) / 86400000) + 25569;
}
