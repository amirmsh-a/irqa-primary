import { computeTotals, scoreOf, visitTotals } from './calc';
import { DOMAINS, type AppData, type Criterion, type Visit } from './types';
import { norm, toISODate, uid } from './util';
import { colName, excelDate, type Cell, type OutCell, type OutSheet, type SheetData } from './xlsx';

/**
 * تخطيط ورقة «Evaluation» كما في مصنف Excel:
 * A م | B إسم المعلم (الزيارة n) | C التاريخ | D المادة | E الصف | ثم لكل معيار عمودان
 * (الدرجة المستحقة، الوزن النسبي) وبعد كل مجال عمودا المجموع، وأخيراً إجمالي الدرجات وإجمالي النسبة.
 */
const FIRST = 5;

function layout(criteria: Criterion[]) {
  let col = FIRST;
  const crit = new Map<string, number>();
  const domainTotal: Record<number, number> = {};
  const domainStart: Record<number, number> = {};
  for (const dom of DOMAINS) {
    domainStart[dom.id] = col;
    for (const c of criteria.filter((x) => x.domain === dom.id)) { crit.set(c.id, col); col += 2; }
    domainTotal[dom.id] = col; col += 2;
  }
  return { crit, domainTotal, domainStart, grand: col, extra: col + 2 };
}

const sorted = (criteria: Criterion[]) => [...criteria].sort((a, b) => a.domain - b.domain || a.sort_order - b.sort_order);

export function buildLogSheet(data: AppData, visits: Visit[]): OutSheet {
  const criteria = sorted(data.criteria);
  const L = layout(criteria);
  const width = L.extra + 3;
  const H = (v: Cell): OutCell => ({ v, s: 'head' });
  const row = (): (OutCell | Cell)[] => Array.from({ length: width }, () => null);

  const rows: (OutCell | Cell)[][] = [];
  rows[0] = [{ v: 'أداة معــارف للملاحظة الصفيــة', s: 'title' }];
  rows[1] = [{ v: `${data.settings.school} — ${data.settings.year}`, s: 'title' }];
  const h1 = row().map(() => H(null)), h2 = row().map(() => H(null)), h3 = row().map(() => H(null));
  ['م', 'إسم المعلم', 'التاريخ', 'المادة', 'الصف'].forEach((t, i) => (h1[i] = H(t)));
  const merges = ['A1:J1', 'A2:J2', ...[0, 1, 2, 3, 4].map((i) => `${colName(i)}6:${colName(i)}8`)];
  for (const dom of DOMAINS) {
    const start = L.domainStart[dom.id], total = L.domainTotal[dom.id];
    h1[start] = H(dom.name);
    merges.push(`${colName(start)}6:${colName(total - 1)}6`);
    h1[total] = H(`مجموع ${dom.name}`);
    merges.push(`${colName(total)}6:${colName(total + 1)}7`);
    h3[total] = H('مجموع الدرجات'); h3[total + 1] = H('مجموع الوزن');
  }
  for (const c of criteria) {
    const col = L.crit.get(c.id)!;
    h2[col] = H(c.title);
    merges.push(`${colName(col)}7:${colName(col + 1)}7`);
    h3[col] = H('الدرجة المستحقة'); h3[col + 1] = H('الوزن نسبي');
  }
  h1[L.grand] = H('الإجمــــالي'); merges.push(`${colName(L.grand)}6:${colName(L.grand + 1)}7`);
  h3[L.grand] = H('إجمالي الدرجات'); h3[L.grand + 1] = H('إجمالي النسبة');
  ['الحصة', 'التغذية الراجعة ومرئيات الملاحظ', 'تأملات المعلم ومرئياته وخطط التحسين'].forEach((t, i) => {
    h1[L.extra + i] = H(t); merges.push(`${colName(L.extra + i)}6:${colName(L.extra + i)}8`);
  });
  rows[5] = h1; rows[6] = h2; rows[7] = h3;

  const name = new Map(data.teachers.map((t) => [t.id, t.name]));
  const subject = new Map(data.subjects.map((s) => [s.id, s.name]));
  const klass = new Map(data.classes.map((c) => [c.id, c.name]));

  visits.forEach((v, i) => {
    const r = row().map((): OutCell => ({ v: null, s: 'num' }));
    const t = visitTotals(v, criteria);
    r[0] = { v: i + 1, s: 'num' };
    r[1] = { v: `${name.get(v.teacher_id) ?? ''} (الزيارة ${v.visit_number} )`, s: 'text' };
    r[2] = { v: excelDate(v.visit_date), s: 'date' };
    r[3] = { v: (v.subject_id && subject.get(v.subject_id)) || '', s: 'text' };
    r[4] = { v: (v.class_id && klass.get(v.class_id)) || '', s: 'text' };
    for (const c of criteria) {
      const s = scoreOf(v, c.id); const col = L.crit.get(c.id)!;
      if (s) { r[col] = { v: s.score, s: 'num' }; r[col + 1] = { v: s.score * s.weight, s: 'num' }; }
    }
    for (const dom of DOMAINS) {
      r[L.domainTotal[dom.id]] = { v: t.domains[dom.id].raw, s: 'total' };
      r[L.domainTotal[dom.id] + 1] = { v: t.domains[dom.id].weighted, s: 'total' };
    }
    r[L.grand] = { v: t.raw, s: 'total' }; r[L.grand + 1] = { v: t.pct, s: 'total' };
    r[L.extra] = { v: v.period, s: 'num' };
    r[L.extra + 1] = { v: v.observer_feedback, s: 'text' };
    r[L.extra + 2] = { v: v.teacher_reflection, s: 'text' };
    rows[8 + i] = r;
  });

  const widths = Array.from({ length: width }, (_, i) => (i === 0 ? 5 : i === 1 ? 40 : i < 5 ? 15 : i >= L.extra + 1 ? 45 : 10));
  return { name: 'Evaluation', rows, merges, widths, freeze: { rows: 8, cols: 2 } };
}

// ---------------------------------------------------------------- الاستيراد

export interface ImportRow {
  line: number; label: string; visit?: Visit; teacherName: string; newTeacher: boolean;
  status: 'new' | 'exists' | 'error'; note: string; pct?: number; filePct?: number;
}

export function parseEvaluation(sheets: SheetData[], data: AppData): { rows: ImportRow[]; sheetName: string } {
  const isHeader = (v: Cell) => ['اسم المعلم'].includes(norm(v));
  let sheet: SheetData | undefined; let headerRow = -1;
  const candidates = [...sheets.filter((s) => s.name.trim().toLowerCase() === 'evaluation'), ...sheets];
  for (const s of candidates) {
    for (let r = 0; r < Math.min(s.rows.length, 30); r++) {
      if (s.rows[r] && isHeader(s.rows[r][1]) && norm(s.rows[r][0]) === 'م') { sheet = s; headerRow = r; break; }
    }
    if (sheet) break;
  }
  if (!sheet) throw new Error('لم يُعثر على ورقة «Evaluation» بالأعمدة المتوقعة (م، إسم المعلم، التاريخ، المادة، الصف…).');

  const criteria = sorted(data.criteria);
  const L = layout(criteria);
  const teacherBy = new Map(data.teachers.map((t) => [norm(t.name), t]));
  const subjectBy = new Map(data.subjects.map((s) => [norm(s.name), s]));
  const classBy = new Map(data.classes.map((c) => [norm(c.name), c]));
  const seen = new Set<string>();
  const out: ImportRow[] = [];

  for (let r = headerRow + 1; r < sheet.rows.length; r++) {
    const row = sheet.rows[r];
    if (!row) continue;
    const label = String(row[1] ?? '').trim();
    if (!label || typeof row[FIRST] !== 'number') continue;
    const m = label.match(/^(.*?)\s*\(\s*الزيارة\s*([12١٢])\s*\)\s*$/);
    const teacherName = (m ? m[1] : label).replace(/\s+/g, ' ').trim();
    const n: 1 | 2 = m && (m[2] === '2' || m[2] === '٢') ? 2 : 1;
    const base = { line: r + 1, label, teacherName, newTeacher: false };

    const date = toISODate(row[2]);
    if (!date) { out.push({ ...base, status: 'error', note: 'التاريخ غير مفهوم' }); continue; }

    const scores: Visit['scores'] = [];
    let bad = '';
    for (const c of criteria) {
      const col = L.crit.get(c.id)!;
      const score = row[col];
      if (typeof score !== 'number' || !Number.isInteger(score) || score < 0 || score > 4) { bad = `درجة غير صحيحة في «${c.title}»`; break; }
      const weighted = row[col + 1];
      const weight = score > 0 && typeof weighted === 'number' ? Math.round((weighted / score) * 100) / 100 : c.weight;
      scores.push({ criterion_id: c.id, score, weight });
    }
    if (bad) { out.push({ ...base, status: 'error', note: bad }); continue; }

    const teacher = teacherBy.get(norm(teacherName));
    const key = `${norm(teacherName)}#${n}`;
    if (seen.has(key)) { out.push({ ...base, status: 'error', note: `الزيارة ${n} مكررة لهذا المعلم داخل الملف` }); continue; }
    seen.add(key);

    const existing = teacher && data.visits.find((v) => v.teacher_id === teacher.id && v.visit_number === n);
    const subject = subjectBy.get(norm(row[3]));
    const klass = classBy.get(norm(row[4]));
    const notes: string[] = [];
    if (!m) notes.push('لم يُذكر رقم الزيارة فاعتُبرت الزيارة 1');
    if (!teacher) notes.push('معلم غير موجود في القائمة وسيُضاف');
    if (row[3] && !subject) notes.push(`المادة «${row[3]}» غير موجودة`);
    if (row[4] && !klass) notes.push(`الصف «${row[4]}» غير موجود`);

    const period = row[L.extra];
    const visit: Visit = {
      id: existing?.id ?? uid(), teacher_id: teacher?.id ?? '', visit_number: n, visit_date: date,
      subject_id: subject?.id ?? null, class_id: klass?.id ?? null,
      period: typeof period === 'number' ? period : null,
      observer_name: data.settings.observer,
      observer_feedback: String(row[L.extra + 1] ?? ''), teacher_reflection: String(row[L.extra + 2] ?? ''),
      scores,
    };
    const pct = computeTotals(scores, criteria).pct;
    const filePct = typeof row[L.grand + 1] === 'number' ? (row[L.grand + 1] as number) : undefined;
    if (filePct != null && Math.abs(filePct - pct) > 0.01) notes.push(`النسبة في الملف ${filePct} والمحسوبة ${pct}`);
    out.push({ ...base, visit, newTeacher: !teacher, status: existing ? 'exists' : 'new', note: notes.join('، '), pct, filePct });
  }
  return { rows: out, sheetName: sheet.name };
}
