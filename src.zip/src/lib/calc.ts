import type { Criterion, Visit, VisitScore } from './types';

export interface DomainTotal { raw: number; weighted: number; maxRaw: number; maxWeighted: number; pct: number }
export interface Totals {
  domains: Record<1 | 2 | 3, DomainTotal>;
  raw: number; maxRaw: number; weighted: number; maxWeighted: number;
  /** النسبة الموزونة من 100 */
  pct: number;
}

const round = (n: number) => Math.round(n * 100) / 100;

/**
 * الوزن النسبي للمعيار = الدرجة المستحقة × الوزن.
 * تُحسب المجاميع من الأوزان المحفوظة مع الزيارة (scores[].weight).
 */
export function computeTotals(scores: VisitScore[], criteria: Criterion[]): Totals {
  const domainOf = new Map(criteria.map((c) => [c.id, c.domain]));
  const domains = {
    1: { raw: 0, weighted: 0, maxRaw: 0, maxWeighted: 0, pct: 0 },
    2: { raw: 0, weighted: 0, maxRaw: 0, maxWeighted: 0, pct: 0 },
    3: { raw: 0, weighted: 0, maxRaw: 0, maxWeighted: 0, pct: 0 },
  } as Totals['domains'];
  for (const s of scores) {
    const d = domainOf.get(s.criterion_id);
    if (!d) continue;
    domains[d].raw += s.score;
    domains[d].weighted += s.score * s.weight;
    domains[d].maxRaw += 4;
    domains[d].maxWeighted += 4 * s.weight;
  }
  let raw = 0, weighted = 0, maxRaw = 0, maxWeighted = 0;
  for (const d of [1, 2, 3] as const) {
    const t = domains[d];
    t.weighted = round(t.weighted); t.maxWeighted = round(t.maxWeighted);
    t.pct = t.maxWeighted ? round((t.weighted / t.maxWeighted) * 100) : 0;
    raw += t.raw; weighted += t.weighted; maxRaw += t.maxRaw; maxWeighted += t.maxWeighted;
  }
  return { domains, raw, maxRaw, weighted: round(weighted), maxWeighted: round(maxWeighted), pct: maxWeighted ? round((weighted / maxWeighted) * 100) : 0 };
}

export const visitTotals = (v: Visit, criteria: Criterion[]) => computeTotals(v.scores, criteria);

export function scoreOf(v: Visit, criterionId: string): VisitScore | undefined {
  return v.scores.find((s) => s.criterion_id === criterionId);
}

export const avg = (xs: number[]) => (xs.length ? round(xs.reduce((a, b) => a + b, 0) / xs.length) : 0);
export const fmt = (n: number) => (Number.isInteger(n) ? String(n) : String(round(n)));
export { round };
