import { useMemo, useState } from 'react';
import { Badge, Card, Empty, Input, PageHeader, Select } from '../components/ui';
import { fmt, round, visitTotals } from '../lib/calc';
import { cx, norm } from '../lib/util';
import { Link } from '../router';
import { useData } from '../store';

export function Delta({ value, suffix = '' }: { value: number | null; suffix?: string }) {
  if (value == null) return <span className="text-muted">—</span>;
  const v = round(value);
  if (v === 0) return <span className="text-muted tnum">بلا تغيير</span>;
  return <span className={cx('font-semibold tnum whitespace-nowrap', v > 0 ? 'text-good' : 'text-bad')}>{v > 0 ? '▲ تحسّن' : '▼ تراجع'} {fmt(Math.abs(v))}{suffix}</span>;
}

export default function Teachers() {
  const d = useData();
  const [q, setQ] = useState('');
  const [state, setState] = useState('');
  const rows = useMemo(() => d.teachers.filter((t) => t.active).map((t) => {
    const v1 = d.visits.find((v) => v.teacher_id === t.id && v.visit_number === 1);
    const v2 = d.visits.find((v) => v.teacher_id === t.id && v.visit_number === 2);
    const p1 = v1 ? visitTotals(v1, d.criteria).pct : null;
    const p2 = v2 ? visitTotals(v2, d.criteria).pct : null;
    return { t, p1, p2, count: (v1 ? 1 : 0) + (v2 ? 1 : 0) };
  }), [d]);
  const nq = norm(q);
  const list = rows.filter((r) => (!nq || norm(r.t.name).includes(nq)) && (state === '' || String(r.count) === state));

  return (
    <div>
      <PageHeader title="المعلمون" sub="افتح ملف المعلم لمقارنة الزيارة 1 بالزيارة 2" />
      <Card className="mb-4">
        <div className="grid gap-3 sm:grid-cols-[1fr_14rem]">
          <Input placeholder="بحث باسم المعلم…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="بحث" />
          <Select value={state} onChange={(e) => setState(e.target.value)} aria-label="حالة الزيارات">
            <option value="">كل المعلمين</option><option value="0">لم يُزر بعد</option><option value="1">زيارة واحدة</option><option value="2">اكتملت الزيارتان</option>
          </Select>
        </div>
      </Card>
      {list.length === 0 ? <Card><Empty title="لا يوجد معلمون مطابقون" /></Card> : (
        <div className="bg-surface border border-line rounded-xl overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-sunken text-right">
              <tr><th className="px-4 py-3 font-semibold">المعلم</th><th className="px-4 py-3 font-semibold">المادة</th><th className="px-4 py-3 font-semibold">الزيارة 1</th><th className="px-4 py-3 font-semibold">الزيارة 2</th><th className="px-4 py-3 font-semibold">التغيّر</th></tr>
            </thead>
            <tbody>
              {list.map(({ t, p1, p2 }) => (
                <tr key={t.id} className="border-t border-line hover:bg-brand-soft/40">
                  <td className="px-4 py-3 font-medium whitespace-nowrap"><Link to={`/teachers/${t.id}`} className="hover:text-brand hover:underline">{t.name}</Link></td>
                  <td className="px-4 py-3 text-muted whitespace-nowrap">{d.subjectName(t.subject_id)}</td>
                  <td className="px-4 py-3 tnum">{p1 != null ? <b>{fmt(p1)}%</b> : <Badge>لم تُنفَّذ</Badge>}</td>
                  <td className="px-4 py-3 tnum">{p2 != null ? <b>{fmt(p2)}%</b> : <Badge>لم تُنفَّذ</Badge>}</td>
                  <td className="px-4 py-3"><Delta value={p1 != null && p2 != null ? p2 - p1 : null} suffix=" نقطة" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
