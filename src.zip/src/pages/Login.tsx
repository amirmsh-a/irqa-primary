import { useEffect, useState, type FormEvent } from 'react';
import { api } from '../data';
import { arabicError } from '../data/api';
import { Button, Field, Input } from '../components/ui';
import { useStore } from '../store';
import seed from '../lib/seed-data.json';

export default function Login() {
  const { setUser, reload, toast, theme, toggleTheme } = useStore();
  const [setup, setSetup] = useState<boolean | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState(seed.settings.observer.split(' - ')[0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.needsSetup().then(setSetup).catch((e) => { setSetup(false); setError(arabicError(e)); });
  }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      if (setup) {
        const u = await api.createAdmin(email.trim(), password, name.trim());
        if (!u) {
          setSetup(false);
          toast('info', 'تم إنشاء الحساب. افتح رسالة التأكيد في بريدك ثم سجّل الدخول.');
          return;
        }
        setUser(u); await reload();
        toast('ok', 'تم إنشاء حساب مدير النظام');
      } else {
        const u = await api.signIn(email.trim(), password);
        setUser(u); await reload();
      }
    } catch (err) {
      setError(arabicError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between bg-brand text-on-brand p-12">
        <p className="font-semibold opacity-80">أداة معارف للملاحظة الصفية</p>
        <div>
          <h1 className="text-5xl font-bold leading-tight">الزيارات الصفية</h1>
          <p className="mt-5 text-xl leading-9 opacity-90">{seed.settings.school}</p>
          <p className="mt-1 opacity-80">{seed.settings.year}</p>
        </div>
        <p className="opacity-70 text-sm leading-6">ثلاثة مجالات، عشرون معياراً، وزيارتان لكل معلم في العام.</p>
      </div>

      <div className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm">
          <div className="lg:hidden mb-8">
            <h1 className="text-3xl font-bold text-brand">الزيارات الصفية</h1>
            <p className="text-muted mt-1">أداة معارف للملاحظة الصفية</p>
          </div>
          <h2 className="text-2xl font-bold">{setup ? 'إنشاء حساب مدير النظام' : 'تسجيل الدخول'}</h2>
          <p className="text-muted mt-2 mb-6 leading-7">
            {setup ? 'هذا أول تشغيل للموقع. أنشئ حساب الملاحظ (مدير النظام)، وبعدها تضيف الملاحظين والمعلمين من الإعدادات.' : 'أدخل البريد الإلكتروني وكلمة المرور.'}
          </p>

          <div className="space-y-4">
            {setup && <Field label="الاسم"><Input value={name} onChange={(e) => setName(e.target.value)} required /></Field>}
            <Field label="البريد الإلكتروني">
              <Input type="email" dir="ltr" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="name@example.com" />
            </Field>
            <Field label="كلمة المرور" hint={setup ? '6 أحرف على الأقل' : undefined}>
              <Input type="password" dir="ltr" autoComplete={setup ? 'new-password' : 'current-password'} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
            </Field>
          </div>

          {error && <p role="alert" className="mt-4 rounded-lg bg-bad-soft text-bad px-3 py-2 text-sm leading-6">{error}</p>}

          <Button type="submit" variant="primary" className="w-full mt-6" disabled={busy || setup === null}>
            {busy ? 'جارٍ التنفيذ…' : setup ? 'إنشاء الحساب والدخول' : 'دخول'}
          </Button>

          {api.mode === 'local' && (
            <p className="mt-5 text-xs text-muted leading-6 rounded-lg bg-warn-soft text-warn px-3 py-2">
              نسخة تجريبية محلية: الحسابات والبيانات تُحفظ في هذا المتصفح فقط.
            </p>
          )}
          <button type="button" onClick={toggleTheme} className="mt-6 text-sm text-muted underline cursor-pointer">
            {theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
          </button>
        </form>
      </div>
    </div>
  );
}
