import { useEffect, useState } from 'react';
import { Badge, Button, Card, Confirm, Empty, Field, Input, Modal, PageHeader, Select, Textarea } from '../components/ui';
import { api } from '../data';
import { arabicError, type NewUser } from '../data/api';
import { fmt } from '../lib/calc';
import { DOMAINS, type ClassRoom, type Criterion, type Invite, type Profile, type Role, type Subject, type Teacher } from '../lib/types';
import { cx, norm, uid } from '../lib/util';
import { useData, useStore } from '../store';

const tabs = [
  ['school', 'بيانات المدرسة'], ['teachers', 'المعلمون'], ['subjects', 'المواد'], ['classes', 'الصفوف'], ['criteria', 'المعايير والأوزان'], ['users', 'المستخدمون'],
] as const;
type Tab = (typeof tabs)[number][0];
const roleLabel: Record<Role, string> = { admin: 'مدير النظام', observer: 'ملاحظ', teacher: 'معلم (قراءة فقط)' };

export default function SettingsPage() {
  const { isAdmin } = useStore();
  const [tab, setTab] = useState<Tab>('school');
  if (!isAdmin) return <Card><Empty title="الإعدادات متاحة لمدير النظام فقط">يمكنك تسجيل الزيارات وإدارة الخطة من القائمة.</Empty></Card>;
  return (
    <div>
      <PageHeader title="الإعدادات" />
      <div className="flex gap-1 overflow-x-auto border-b border-line mb-5" role="tablist">
        {tabs.map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={cx('px-4 py-2.5 font-medium whitespace-nowrap border-b-2 -mb-px cursor-pointer', tab === id ? 'border-brand text-brand' : 'border-transparent text-muted hover:text-ink')}>{label}</button>
        ))}
      </div>
      {tab === 'school' && <School />}
      {tab === 'teachers' && <TeachersTab />}
      {tab === 'subjects' && <Subjects />}
      {tab === 'classes' && <Classes />}
      {tab === 'criteria' && <Criteria />}
      {tab === 'users' && <Users />}
    </div>
  );
}

function School() {
  const d = useData();
  const { run } = useStore();
  const [s, setS] = useState(d.settings);
  const dirty = JSON.stringify(s) !== JSON.stringify(d.settings);
  return (
    <Card title="بيانات المدرسة" className="max-w-2xl">
      <div className="space-y-4">
        <Field label="المدرسة"><Input value={s.school} onChange={(e) => setS({ ...s, school: e.target.value })} /></Field>
        <Field label="العام الدراسي"><Input value={s.year} onChange={(e) => setS({ ...s, year: e.target.value })} /></Field>
        <Field label="الملاحظ" hint="يظهر في ترويسة التقرير وخانة التوقيع"><Input value={s.observer} onChange={(e) => setS({ ...s, observer: e.target.value })} /></Field>
      </div>
      <div className="flex justify-end mt-5"><Button variant="primary" disabled={!dirty} onClick={() => run(() => api.saveSettings(s), 'تم حفظ بيانات المدرسة')}>حفظ البيانات</Button></div>
    </Card>
  );
}

function TeachersTab() {
  const d = useData();
  const { run } = useStore();
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState<Teacher | null>(null);
  const [del, setDel] = useState<Teacher | null>(null);
  const list = d.teachers.filter((t) => !q || norm(t.name).includes(norm(q)));
  return (
    <Card title={`المعلمون (${d.teachers.length})`} actions={<Button variant="primary" small onClick={() => setEdit({ id: uid(), name: '', subject_id: null, active: true })}>إضافة معلم</Button>}>
      <Input placeholder="بحث باسم المعلم…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-3 max-w-md" aria-label="بحث" />
      <ul className="divide-y divide-line">
        {list.map((t) => (
          <li key={t.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
            <span className={cx('font-medium', !t.active && 'text-muted line-through')}>{t.name}</span>
            <span className="flex items-center gap-2">
              <span className="text-sm text-muted">{d.subjectName(t.subject_id)}</span>
              {!t.active && <Badge tone="warn">موقوف</Badge>}
              <Button small onClick={() => setEdit({ ...t })}>تعديل</Button>
              <Button small variant="ghost" className="text-bad" onClick={() => setDel(t)}>حذف</Button>
            </span>
          </li>
        ))}
      </ul>
      {edit && (
        <Modal title={d.teacherById.has(edit.id) ? 'تعديل بيانات المعلم' : 'إضافة معلم'} onClose={() => setEdit(null)}
          footer={<><Button onClick={() => setEdit(null)}>إلغاء</Button><Button variant="primary" disabled={!edit.name.trim()} onClick={async () => { if (await run(() => api.saveTeacher({ ...edit, name: edit.name.trim() }), 'تم حفظ بيانات المعلم')) setEdit(null); }}>حفظ</Button></>}>
          <div className="space-y-4">
            <Field label="اسم المعلم"><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} autoFocus /></Field>
            <Field label="المادة" hint="تُعبَّأ تلقائياً في نموذج الزيارة عند اختيار المعلم">
              <Select value={edit.subject_id ?? ''} onChange={(e) => setEdit({ ...edit, subject_id: e.target.value || null })}>
                <option value="">— غير محددة —</option>{d.subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </Field>
            <label className="flex items-center gap-2"><input type="checkbox" className="w-5 h-5" checked={edit.active} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} /> على رأس العمل (يظهر في القوائم والإحصاءات)</label>
          </div>
        </Modal>
      )}
      {del && <Confirm title="حذف المعلم" confirmLabel="حذف المعلم" onClose={() => setDel(null)} text={<>سيُحذف «{del.name}» من القائمة. لا يمكن حذف معلم له زيارات مسجلة، ويمكنك إيقافه بدلاً من ذلك.</>} onConfirm={() => run(() => api.deleteTeacher(del.id), 'تم حذف المعلم')} />}
    </Card>
  );
}

function Subjects() {
  const d = useData();
  const { run } = useStore();
  const [name, setName] = useState('');
  const [edit, setEdit] = useState<Subject | null>(null);
  const [del, setDel] = useState<Subject | null>(null);
  const add = async () => { if (await run(() => api.saveSubject({ id: uid(), name: name.trim(), sort_order: Math.max(0, ...d.subjects.map((s) => s.sort_order)) + 1 }), 'تمت إضافة المادة')) setName(''); };
  return (
    <Card title={`المواد (${d.subjects.length})`} className="max-w-2xl">
      <div className="flex gap-2 mb-3"><Input placeholder="اسم مادة جديدة" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && name.trim() && add()} /><Button variant="primary" disabled={!name.trim()} onClick={add}>إضافة</Button></div>
      <ul className="divide-y divide-line">
        {d.subjects.map((s) => (
          <li key={s.id} className="py-2 flex items-center justify-between gap-2">
            {edit?.id === s.id
              ? <><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} autoFocus /><Button small variant="primary" onClick={async () => { if (await run(() => api.saveSubject({ ...edit, name: edit.name.trim() }), 'تم حفظ المادة')) setEdit(null); }}>حفظ</Button><Button small onClick={() => setEdit(null)}>إلغاء</Button></>
              : <><span>{s.name}</span><span className="flex gap-2"><Button small onClick={() => setEdit({ ...s })}>تعديل</Button><Button small variant="ghost" className="text-bad" onClick={() => setDel(s)}>حذف</Button></span></>}
          </li>
        ))}
      </ul>
      {del && <Confirm title="حذف المادة" confirmLabel="حذف المادة" onClose={() => setDel(null)} text={<>ستُحذف مادة «{del.name}»، وتبقى الزيارات المسجلة عليها دون مادة.</>} onConfirm={() => run(() => api.deleteSubject(del.id), 'تم حذف المادة')} />}
    </Card>
  );
}

function Classes() {
  const d = useData();
  const { run } = useStore();
  const [grade, setGrade] = useState('');
  const [section, setSection] = useState('');
  const [del, setDel] = useState<ClassRoom | null>(null);
  const grades = [...new Set(d.classes.map((c) => c.grade))];
  const add = async () => {
    const c: ClassRoom = { id: uid(), grade: grade.trim(), section: section.trim(), name: `${grade.trim()} ${section.trim()}`, sort_order: Math.max(0, ...d.classes.map((x) => x.sort_order)) + 1 };
    if (await run(() => api.saveClass(c), 'تمت إضافة الصف')) setSection('');
  };
  return (
    <Card title={`الصفوف (${d.classes.length})`} className="max-w-3xl">
      <div className="grid grid-cols-[1fr_1fr_auto] gap-2 mb-4 items-end">
        <Field label="الصف"><Input list="grades" placeholder="مثل: خامس" value={grade} onChange={(e) => setGrade(e.target.value)} /></Field>
        <Field label="الفصل"><Input placeholder="مثل: ثامن" value={section} onChange={(e) => setSection(e.target.value)} /></Field>
        <Button variant="primary" disabled={!grade.trim() || !section.trim()} onClick={add}>إضافة</Button>
        <datalist id="grades">{grades.map((g) => <option key={g} value={g} />)}</datalist>
      </div>
      {grades.map((g) => (
        <div key={g} className="py-3 border-t border-line">
          <p className="font-semibold mb-2">الصف ال{g}</p>
          <div className="flex flex-wrap gap-2">
            {d.classes.filter((c) => c.grade === g).map((c) => (
              <span key={c.id} className="inline-flex items-center gap-1 bg-sunken rounded-lg ps-3 pe-1 py-1 text-sm">
                {c.name}
                <button type="button" aria-label={`حذف ${c.name}`} className="text-muted hover:text-bad px-1.5 text-lg leading-none cursor-pointer" onClick={() => setDel(c)}>×</button>
              </span>
            ))}
          </div>
        </div>
      ))}
      {del && <Confirm title="حذف الصف" confirmLabel="حذف الصف" onClose={() => setDel(null)} text={<>سيُحذف «{del.name}»، وتبقى الزيارات المسجلة عليه دون صف.</>} onConfirm={() => run(() => api.deleteClass(del.id), 'تم حذف الصف')} />}
    </Card>
  );
}

function Criteria() {
  const d = useData();
  const { run } = useStore();
  const [edit, setEdit] = useState<Criterion | null>(null);
  const [weight, setWeight] = useState('');
  const sum = d.criteria.reduce((a, c) => a + c.weight, 0);
  return (
    <Card title="المعايير والأوزان" actions={<Badge tone={sum === 25 ? 'good' : 'warn'}>مجموع الأوزان: {fmt(sum)}</Badge>}>
      <p className="text-sm text-muted leading-7 mb-4">
        تعديل الوزن يُطبَّق على الزيارات الجديدة فقط. الزيارات السابقة تحتفظ بالأوزان التي سُجلت بها فلا تتغير نتائجها.
        {sum !== 25 && <span className="text-warn"> مجموع الأوزان في الأداة الأصلية 25 (النسبة من 100).</span>}
      </p>
      {DOMAINS.map((dom) => {
        const list = d.criteria.filter((c) => c.domain === dom.id);
        return (
          <div key={dom.id} className="mb-5">
            <p className="font-bold text-brand border-b-2 border-brand pb-1 mb-1 flex justify-between"><span>{dom.id}. {dom.name}</span><span className="text-sm font-normal text-muted">الحد الأعلى للوزن: {fmt(list.reduce((a, c) => a + c.weight, 0) * 4)}</span></p>
            <ul className="divide-y divide-line">
              {list.map((c) => (
                <li key={c.id} className="py-3 flex items-start justify-between gap-3">
                  <div className="min-w-0"><p className="font-medium">{c.letter}. {c.title}</p><p className="text-sm text-muted leading-6">{c.description}</p></div>
                  <div className="flex items-center gap-2 shrink-0"><Badge tone="brand">الوزن {fmt(c.weight)}</Badge><Button small onClick={() => { setEdit({ ...c }); setWeight(String(c.weight)); }}>تعديل</Button></div>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
      {edit && (
        <Modal wide title="تعديل المعيار" onClose={() => setEdit(null)}
          footer={<><Button onClick={() => setEdit(null)}>إلغاء</Button><Button variant="primary" disabled={!edit.title.trim() || !(Number(weight) >= 0) || weight.trim() === ''} onClick={async () => { if (await run(() => api.saveCriterion({ ...edit, title: edit.title.trim(), weight: Number(weight) }), 'تم حفظ المعيار')) setEdit(null); }}>حفظ المعيار</Button></>}>
          <div className="space-y-4">
            <div className="grid grid-cols-[1fr_7rem] gap-3">
              <Field label="عنوان المعيار"><Input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
              <Field label="الوزن"><Input type="number" step="0.5" min="0" dir="ltr" value={weight} onChange={(e) => setWeight(e.target.value)} /></Field>
            </div>
            <Field label="تفاصيل المعيار"><Textarea rows={4} value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
          </div>
        </Modal>
      )}
    </Card>
  );
}

function Users() {
  const d = useData();
  const { user, toast } = useStore();
  const [users, setUsers] = useState<Profile[]>([]);
  const [invites, setInvites] = useState<Invite[]>([]);
  const [add, setAdd] = useState<NewUser | null>(null);
  const [edit, setEdit] = useState<Profile | null>(null);
  const [del, setDel] = useState<Profile | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => api.listUsers().then((r) => { setUsers(r.users); setInvites(r.invites); }).catch((e) => toast('error', arabicError(e)));
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const act = async (fn: () => Promise<void>, ok: string) => {
    setBusy(true);
    try { await fn(); await load(); toast('ok', ok); return true; } catch (e) { toast('error', arabicError(e)); return false; } finally { setBusy(false); }
  };
  const admins = users.filter((u) => u.role === 'admin').length;
  const valid = add && add.email.trim() && add.password.length >= 6 && add.full_name.trim() && (add.role !== 'teacher' || add.teacher_id);

  const RoleFields = ({ value, onChange }: { value: { role: Role; teacher_id: string | null; full_name: string }; onChange(v: { role: Role; teacher_id: string | null; full_name: string }): void }) => (
    <>
      <Field label="الصلاحية">
        <Select value={value.role} onChange={(e) => onChange({ ...value, role: e.target.value as Role, teacher_id: e.target.value === 'teacher' ? value.teacher_id : null })}>
          <option value="observer">ملاحظ: يسجل الزيارات ويدير الخطة</option>
          <option value="teacher">معلم: يرى زياراته فقط ويكتب تأملاته</option>
          <option value="admin">مدير النظام: كل الصلاحيات</option>
        </Select>
      </Field>
      {value.role === 'teacher' && (
        <Field label="المعلم المرتبط بالحساب">
          <Select value={value.teacher_id ?? ''} onChange={(e) => { const t = d.teacherById.get(e.target.value); onChange({ ...value, teacher_id: e.target.value || null, full_name: value.full_name || t?.name || '' }); }}>
            <option value="">— اختر المعلم —</option>{d.teachers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
        </Field>
      )}
    </>
  );

  return (
    <Card title={`المستخدمون (${users.length})`} actions={<Button variant="primary" small onClick={() => setAdd({ email: '', password: '', full_name: '', role: 'observer', teacher_id: null })}>إضافة مستخدم</Button>}>
      {api.mode === 'supabase' && <p className="text-sm text-muted leading-7 mb-3">إذا كان «تأكيد البريد الإلكتروني» مفعّلاً في Supabase فسيحتاج المستخدم الجديد إلى فتح رسالة التأكيد قبل أول دخول.</p>}
      <ul className="divide-y divide-line">
        {users.map((u) => (
          <li key={u.id} className="py-3 flex flex-wrap items-center justify-between gap-2">
            <div><p className="font-medium">{u.full_name || '—'} {u.id === user?.id && <Badge tone="brand">أنت</Badge>}</p><p className="text-sm text-muted" dir="ltr" style={{ textAlign: 'right' }}>{u.email}</p></div>
            <span className="flex items-center gap-2">
              <Badge tone={u.role === 'admin' ? 'brand' : u.role === 'observer' ? 'good' : 'neutral'}>{roleLabel[u.role]}</Badge>
              <Button small onClick={() => setEdit({ ...u })}>تعديل</Button>
              <Button small variant="ghost" className="text-bad" disabled={u.id === user?.id} onClick={() => setDel(u)}>حذف</Button>
            </span>
          </li>
        ))}
        {invites.map((i) => <li key={i.email} className="py-3 flex justify-between gap-2 text-muted"><span dir="ltr">{i.email}</span><Badge tone="warn">بانتظار إنشاء الحساب</Badge></li>)}
      </ul>

      {add && (
        <Modal title="إضافة مستخدم" onClose={() => setAdd(null)}
          footer={<><Button onClick={() => setAdd(null)}>إلغاء</Button><Button variant="primary" disabled={!valid || busy} onClick={async () => { if (await act(() => api.createUser(add), 'تم إنشاء الحساب')) setAdd(null); }}>إنشاء الحساب</Button></>}>
          <div className="space-y-4">
            <RoleFields value={add} onChange={(v) => setAdd({ ...add, ...v })} />
            <Field label="الاسم"><Input value={add.full_name} onChange={(e) => setAdd({ ...add, full_name: e.target.value })} /></Field>
            <Field label="البريد الإلكتروني"><Input type="email" dir="ltr" value={add.email} onChange={(e) => setAdd({ ...add, email: e.target.value })} /></Field>
            <Field label="كلمة المرور" hint="6 أحرف على الأقل. سلّمها للمستخدم ليدخل بها."><Input dir="ltr" value={add.password} onChange={(e) => setAdd({ ...add, password: e.target.value })} /></Field>
          </div>
        </Modal>
      )}
      {edit && (
        <Modal title="تعديل المستخدم" onClose={() => setEdit(null)}
          footer={<><Button onClick={() => setEdit(null)}>إلغاء</Button><Button variant="primary" disabled={busy || (edit.role === 'teacher' && !edit.teacher_id)} onClick={async () => {
            if (edit.id === user?.id && edit.role !== 'admin' && admins <= 1) { toast('error', 'لا يمكن إزالة صلاحية آخر مدير للنظام.'); return; }
            if (await act(() => api.updateUser(edit.id, { full_name: edit.full_name, role: edit.role, teacher_id: edit.teacher_id }), 'تم حفظ المستخدم')) setEdit(null);
          }}>حفظ</Button></>}>
          <div className="space-y-4">
            <Field label="الاسم"><Input value={edit.full_name} onChange={(e) => setEdit({ ...edit, full_name: e.target.value })} /></Field>
            <RoleFields value={edit} onChange={(v) => setEdit({ ...edit, ...v })} />
          </div>
        </Modal>
      )}
      {del && <Confirm title="حذف المستخدم" confirmLabel="حذف المستخدم" onClose={() => setDel(null)} text={<>لن يتمكن «{del.full_name || del.email}» من الدخول إلى الموقع بعد الحذف.</>} onConfirm={() => act(() => api.deleteUser(del.id), 'تم حذف المستخدم')} />}
    </Card>
  );
}
