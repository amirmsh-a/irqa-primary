import { useMemo, useState } from 'react';
import { Badge, Button, Card, Field, Input, Modal, PageHeader, Select } from '../components/ui';
import { api } from '../data';
import { fmt, visitTotals } from '../lib/calc';
import { PERIODS, WEEKS, type ScheduleRow, type Teacher } from '../lib/types';
import { cx, dayName, downloadBlob, gregorian, hijri, monthLabel, norm, todayISO } from '../lib/util';
import { excelDate, writeWorkbook, type OutCell } from '../lib/xlsx';
import { Link, navigate } from '../router';
import { useData, useStore } from '../store';

type State = 'done' | 'overdue' | 'upcoming' | 'none';
const emptyRow = (teacher_id: string): ScheduleRow => ({
  teacher_id, specialty: '', status: 'في الموعد',
  v1_week: '', v1_date: null, v1_period: null, v1_class_id: null,
  v2_week: '', v2_date: null, v2_period: null, v2_class_id: null,
});

export default function Schedule() {
  const d = useData();
  const { run } = useStore();
  const today = todayISO();
  const [tab, setTab] = useState<'table' | 'calendar'>('table');
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('');
  const [edit, setEdit] = useState<ScheduleRow | null>(null);
  const [month, setMonth] = useState(() => { const n = new Date(); return { y: n.getFullYear(), m: n.getMonth() }; });

  const rows = useMemo(() => d.teachers.filter((t) => t.active).map((t) => {
    const row = d.schedule.find((s) => s.teacher_id === t.id) ?? emptyRow(t.id);
    const slot = (n: 1 | 2) => {
      const visit = d.visits.find((v) => v.teacher_id === t.id && v.visit_number === n);
      const date = n === 1 ? row.v1_date : row.v2_date;
      const state: State = visit ? 'done' : !date ? 'none' : date < today ? 'overdue' : 'upcoming';
      return {
        n, visit, date, state, week: n === 1 ? row.v1_week : row.v2_week, period: n === 1 ? row.v1_period : row.v2_period,
        class_id: n === 1 ? row.v1_class_id : row.v2_class_id, pct: visit ? visitTotals(visit, d.criteria).pct : null,
      };
    };
    return { t, row, s1: slot(1), s2: slot(2) };
  }), [d, today]);

  const overdue = rows.flatMap((r) => [r.s1, r.s2].filter((s) => s.state === 'overdue').map((s) => ({ t: r.t, ...s }))).sort((a, b) => a.date!.localeCompare(b.date!));
  const nq = norm(q);
  const list = rows.filter((r) => (!nq || norm(r.t.name + ' ' + r.row.specialty).includes(nq)))
    .filter((r) => filter === '' || [r.s1.state, r.s2.state].includes(filter as State));

  const exportExcel = async () => {
    const H = (v: string): OutCell => ({ v, s: 'head' });
    const head1 = [H('اسم المعلم'), H('التخصص'), H('التنفيذ'), H('الزيارة الأولى'), H(''), H(''), H(''), H(''), H(''), H('الزيارة الثانية'), H(''), H(''), H(''), H(''), H('')];
    const sub = ['الأسبوع', 'اليوم', 'التاريخ', 'الحصة', 'الفصل', 'التقييم'];
    const head2 = [H(''), H(''), H(''), ...sub.map(H), ...sub.map(H)];
    const body = rows.map((r) => [
      r.t.name, r.row.specialty || d.subjectName(r.t.subject_id), r.row.status,
      ...[r.s1, r.s2].flatMap((s): OutCell[] => [
        { v: s.week, s: 'text' }, { v: dayName(s.date), s: 'text' }, s.date ? { v: excelDate(s.date), s: 'date' } : { v: null, s: 'num' },
        { v: s.period, s: 'num' }, { v: s.class_id ? d.className(s.class_id) : '', s: 'text' }, { v: s.pct, s: 'num' },
      ]),
    ]);
    const blob = await writeWorkbook([{ name: 'خطة الزيارات', rows: [head1, head2, ...body], merges: ['A1:A2', 'B1:B2', 'C1:C2', 'D1:I1', 'J1:O1'], widths: [36, 16, 12, 11, 11, 13, 8, 14, 10, 11, 11, 13, 8, 14, 10], freeze: { rows: 2, cols: 1 } }]);
    downloadBlob(blob, `خطة-الزيارات-${today}.xlsx`);
  };

  const Slot = ({ t, s }: { t: Teacher; s: (typeof rows)[number]['s1'] }) => (
    <>
      <td className="px-2 py-2 border-t border-r border-line text-center whitespace-nowrap">{s.week || '—'}</td>
      <td className="px-2 py-2 border-t border-line text-center whitespace-nowrap">{dayName(s.date) || '—'}</td>
      <td className="px-2 py-2 border-t border-line text-center whitespace-nowrap tnum" title={hijri(s.date)}>{s.date ? gregorian(s.date) : '—'}</td>
      <td className="px-2 py-2 border-t border-line text-center tnum">{s.period ?? '—'}</td>
      <td className="px-2 py-2 border-t border-line text-center whitespace-nowrap">{s.class_id ? d.className(s.class_id) : '—'}</td>
      <td className="px-2 py-2 border-t border-line text-center whitespace-nowrap">
        {s.state === 'done' && <Link to={`/visits/${s.visit!.id}`} className="font-bold text-good tnum hover:underline">{fmt(s.pct!)}%</Link>}
        {s.state === 'overdue' && <button type="button" className="cursor-pointer" onClick={() => navigate(`/visits/new?teacher=${t.id}&n=${s.n}`)}><Badge tone="bad">متأخرة</Badge></button>}
        {s.state === 'upcoming' && <Badge tone="brand">قادمة</Badge>}
        {s.state === 'none' && <span className="text-muted">—</span>}
      </td>
    </>
  );

  // ---- التقويم
  const events = rows.flatMap((r) => [r.s1, r.s2].filter((s) => s.date).map((s) => ({ t: r.t, ...s })));
  const first = new Date(month.y, month.m, 1);
  const days = new Date(month.y, month.m + 1, 0).getDate();
  const cells: (string | null)[] = [...Array(first.getDay()).fill(null), ...Array.from({ length: days }, (_, i) => `${month.y}-${String(month.m + 1).padStart(2, '0')}-${String(i + 1).padStart(2, '0')}`)];
  while (cells.length % 7) cells.push(null);
  const shift = (by: number) => setMonth(({ y, m }) => { const n = new Date(y, m + by, 1); return { y: n.getFullYear(), m: n.getMonth() }; });
  const tone: Record<State, string> = { done: 'bg-good-soft text-good', overdue: 'bg-bad-soft text-bad', upcoming: 'bg-brand-soft text-brand', none: '' };

  return (
    <div>
      <PageHeader title="خطة الزيارات" sub="عمود التقييم يُملأ تلقائياً بعد تنفيذ الزيارة"
        actions={<>
          <div className="inline-flex rounded-lg border border-line overflow-hidden" role="tablist">
            {(['table', 'calendar'] as const).map((v) => (
              <button key={v} type="button" role="tab" aria-selected={tab === v} onClick={() => setTab(v)} className={cx('px-4 min-h-11 font-medium cursor-pointer', tab === v ? 'bg-brand text-on-brand' : 'bg-surface')}>{v === 'table' ? 'الجدول' : 'التقويم'}</button>
            ))}
          </div>
          <Button onClick={exportExcel}>تصدير Excel</Button>
        </>} />

      {overdue.length > 0 && (
        <div className="mb-5 rounded-xl border border-bad/30 bg-bad-soft px-4 py-3">
          <p className="font-semibold text-bad mb-2">زيارات متأخرة عن موعدها ({overdue.length})</p>
          <ul className="flex flex-wrap gap-2">
            {overdue.slice(0, 12).map((o) => (
              <li key={o.t.id + o.n}>
                <button type="button" onClick={() => navigate(`/visits/new?teacher=${o.t.id}&n=${o.n}`)} className="bg-surface border border-bad/30 rounded-lg px-3 py-1.5 text-sm cursor-pointer hover:border-bad">
                  {o.t.name} — الزيارة {o.n} <span className="text-muted tnum">({gregorian(o.date)})</span>
                </button>
              </li>
            ))}
            {overdue.length > 12 && <li className="text-sm text-bad self-center">و{overdue.length - 12} أخرى</li>}
          </ul>
        </div>
      )}

      {tab === 'table' ? (
        <>
          <Card className="mb-4">
            <div className="grid gap-3 sm:grid-cols-[1fr_14rem]">
              <Input placeholder="بحث باسم المعلم أو التخصص…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="بحث" />
              <Select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="الحالة">
                <option value="">كل الحالات</option><option value="overdue">متأخرة</option><option value="upcoming">قادمة</option><option value="done">منفذة</option><option value="none">غير مجدولة</option>
              </Select>
            </div>
          </Card>
          <div className="bg-surface border border-line rounded-xl overflow-auto max-h-[75vh]">
            <table className="text-sm border-separate border-spacing-0 min-w-full">
              <thead className="sticky top-0 z-20 bg-sunken">
                <tr>
                  <th rowSpan={2} className="px-3 py-2 font-semibold text-right sticky right-0 bg-sunken z-10">اسم المعلم</th>
                  <th rowSpan={2} className="px-2 py-2 font-semibold">التخصص</th>
                  <th rowSpan={2} className="px-2 py-2 font-semibold">التنفيذ</th>
                  <th colSpan={6} className="px-2 py-2 font-semibold border-r border-line">الزيارة الأولى</th>
                  <th colSpan={6} className="px-2 py-2 font-semibold border-r border-line">الزيارة الثانية</th>
                  <th rowSpan={2} className="px-2 py-2 border-r border-line" />
                </tr>
                <tr className="text-xs text-muted">
                  {[1, 2].flatMap((n) => ['الأسبوع', 'اليوم', 'التاريخ', 'الحصة', 'الفصل', 'التقييم'].map((h, i) => <th key={n + h} className={cx('px-2 py-1 font-normal border-t border-line', i === 0 && 'border-r')}>{h}</th>))}
                </tr>
              </thead>
              <tbody>
                {list.map((r) => (
                  <tr key={r.t.id} className="hover:bg-brand-soft/40">
                    <td className="px-3 py-2 border-t border-line font-medium whitespace-nowrap sticky right-0 bg-surface z-10"><Link to={`/teachers/${r.t.id}`} className="hover:text-brand hover:underline">{r.t.name}</Link></td>
                    <td className="px-2 py-2 border-t border-line text-center whitespace-nowrap">{r.row.specialty || d.subjectName(r.t.subject_id)}</td>
                    <td className="px-2 py-2 border-t border-line text-center"><Badge tone={r.row.status === 'تعديل' ? 'warn' : 'neutral'}>{r.row.status}</Badge></td>
                    <Slot t={r.t} s={r.s1} /><Slot t={r.t} s={r.s2} />
                    <td className="px-2 py-2 border-t border-r border-line"><Button small onClick={() => setEdit({ ...r.row })}>تعديل الموعد</Button></td>
                  </tr>
                ))}
                {list.length === 0 && <tr><td colSpan={16} className="text-center text-muted py-8">لا توجد نتائج مطابقة</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <Button small onClick={() => shift(-1)}>الشهر السابق</Button>
            <p className="font-bold text-lg">{monthLabel(month.y, month.m)}</p>
            <Button small onClick={() => shift(1)}>الشهر التالي</Button>
          </div>
          <div className="overflow-x-auto">
            <div className="grid grid-cols-7 min-w-[700px] border-r border-t border-line">
              {['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map((n) => <div key={n} className="bg-sunken text-center text-sm font-semibold py-2 border-l border-b border-line">{n}</div>)}
              {cells.map((iso, i) => (
                <div key={i} className={cx('min-h-24 border-l border-b border-line p-1.5', !iso && 'bg-sunken/50', iso === today && 'ring-2 ring-inset ring-brand')}>
                  {iso && (
                    <>
                      <p className="text-xs text-muted flex justify-between tnum"><b className="text-ink text-sm">{Number(iso.slice(8))}</b><span>{hijri(iso).split(' ').slice(0, 2).join(' ')}</span></p>
                      <ul className="mt-1 space-y-1">
                        {events.filter((e) => e.date === iso).map((e) => (
                          <li key={e.t.id + e.n}>
                            <button type="button" title={`${e.t.name} — الزيارة ${e.n}`} className={cx('w-full text-right rounded px-1.5 py-1 text-xs leading-4 cursor-pointer', tone[e.state])}
                              onClick={() => (e.visit ? navigate(`/visits/${e.visit.id}`) : navigate(`/visits/new?teacher=${e.t.id}&n=${e.n}`))}>
                              {e.t.name.split(' ').slice(0, 2).join(' ')} <span className="opacity-75">ز{e.n}</span>
                            </button>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
          <p className="flex flex-wrap gap-3 mt-4 text-sm"><Badge tone="good">منفذة</Badge><Badge tone="brand">قادمة</Badge><Badge tone="bad">متأخرة</Badge><span className="text-muted">اضغط على الموعد لفتح التقرير أو لتسجيل الزيارة.</span></p>
        </Card>
      )}

      {edit && (
        <Modal wide title={`موعد زيارات: ${d.teacherName(edit.teacher_id)}`} onClose={() => setEdit(null)}
          footer={<><Button onClick={() => setEdit(null)}>إلغاء</Button><Button variant="primary" onClick={async () => { if (await run(() => api.saveSchedule(edit), 'تم حفظ الموعد')) setEdit(null); }}>حفظ الموعد</Button></>}>
          <div className="grid gap-4 sm:grid-cols-2 mb-5">
            <Field label="التخصص"><Input value={edit.specialty} onChange={(e) => setEdit({ ...edit, specialty: e.target.value })} placeholder={d.subjectName(d.teacherById.get(edit.teacher_id)?.subject_id ?? null)} /></Field>
            <Field label="التنفيذ">
              <Select value={edit.status} onChange={(e) => setEdit({ ...edit, status: e.target.value as ScheduleRow['status'] })}><option>في الموعد</option><option>تعديل</option></Select>
            </Field>
          </div>
          {([1, 2] as const).map((n) => {
            const k = (f: string) => `v${n}_${f}` as keyof ScheduleRow;
            const date = edit[k('date')] as string | null;
            return (
              <fieldset key={n} className="border border-line rounded-xl p-4 mb-4">
                <legend className="px-2 font-semibold">{n === 1 ? 'الزيارة الأولى' : 'الزيارة الثانية'}</legend>
                <div className="grid gap-3 grid-cols-2 sm:grid-cols-4">
                  <Field label="الأسبوع">
                    <Select value={edit[k('week')] as string} onChange={(e) => setEdit({ ...edit, [k('week')]: e.target.value })}>
                      <option value="">—</option>{WEEKS.map((w) => <option key={w}>{w}</option>)}
                    </Select>
                  </Field>
                  <Field label="التاريخ" hint={date ? `${dayName(date)} · ${hijri(date)}` : 'اليوم يُحسب تلقائياً'}>
                    <Input type="date" value={date ?? ''} onChange={(e) => setEdit({ ...edit, [k('date')]: e.target.value || null })} />
                  </Field>
                  <Field label="الحصة">
                    <Select value={String(edit[k('period')] ?? '')} onChange={(e) => setEdit({ ...edit, [k('period')]: e.target.value ? Number(e.target.value) : null })}>
                      <option value="">—</option>{PERIODS.map((p) => <option key={p} value={p}>{p}</option>)}
                    </Select>
                  </Field>
                  <Field label="الفصل">
                    <Select value={(edit[k('class_id')] as string | null) ?? ''} onChange={(e) => setEdit({ ...edit, [k('class_id')]: e.target.value || null })}>
                      <option value="">—</option>{d.classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </Select>
                  </Field>
                </div>
              </fieldset>
            );
          })}
        </Modal>
      )}
    </div>
  );
}
