import { useRef, useState, type ReactNode } from 'react';
import ReportSheet from '../components/ReportSheet';
import { Badge, Button, Card, PageHeader } from '../components/ui';
import { api } from '../data';
import { arabicError } from '../data/api';
import { fmt, visitTotals } from '../lib/calc';
import { buildLogSheet, parseEvaluation, type ImportRow } from '../lib/evaluation';
import { DOMAINS, type Teacher } from '../lib/types';
import { downloadBlob, gregorian, norm, todayISO, uid } from '../lib/util';
import { excelDate, readWorkbook, writeWorkbook, type OutCell } from '../lib/xlsx';
import { useData, useStore } from '../store';
import { printWithTitle } from './VisitView';

export default function DataPage() {
  const d = useData();
  const { data, reload, toast } = useStore();
  const input = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<ImportRow[] | null>(null);
  const [fileName, setFileName] = useState('');
  const [replace, setReplace] = useState(false);
  const [busy, setBusy] = useState(false);
  const [bulk, setBulk] = useState<'full' | 'short' | null>(null);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = parseEvaluation(await readWorkbook(await file.arrayBuffer()), data!);
      setRows(parsed.rows); setFileName(`${file.name} — ورقة ${parsed.sheetName}`);
      if (!parsed.rows.length) toast('info', 'لم يُعثر على صفوف زيارات في الملف.');
    } catch (e) {
      setRows(null); toast('error', arabicError(e));
    } finally {
      if (input.current) input.current.value = '';
    }
  };

  const toImport = (rows ?? []).filter((r) => r.status === 'new' || (r.status === 'exists' && replace));
  const doImport = async () => {
    setBusy(true);
    let done = 0;
    try {
      const created = new Map<string, Teacher>();
      for (const r of toImport) {
        const v = { ...r.visit! };
        if (r.newTeacher) {
          const key = norm(r.teacherName);
          let t = created.get(key);
          if (!t) { t = { id: uid(), name: r.teacherName, subject_id: v.subject_id, active: true }; await api.saveTeacher(t); created.set(key, t); }
          v.teacher_id = t.id;
        }
        await api.saveVisit(v);
        done++;
      }
      toast('ok', `تم استيراد ${done} زيارة إلى سجل التقييم`);
      setRows(null);
    } catch (e) {
      toast('error', `توقف الاستيراد بعد ${done} زيارة. ${arabicError(e)}`);
    } finally {
      await reload(); setBusy(false);
    }
  };

  const sortedVisits = [...d.visits].sort((a, b) => a.visit_date.localeCompare(b.visit_date));
  const exportLog = async () => downloadBlob(await writeWorkbook([buildLogSheet(data!, sortedVisits)]), `سجل-التقييم-${todayISO()}.xlsx`);
  const exportSummary = async () => {
    const H = (v: string): OutCell => ({ v, s: 'head' });
    const head = [H('م'), H('اسم المعلم'), H('المادة'), ...[1, 2].flatMap((n) => [H(`تاريخ الزيارة ${n}`), ...DOMAINS.map((dom) => H(`${dom.name} (${n})`)), H(`إجمالي الدرجات (${n})`), H(`النسبة الموزونة (${n})`)]), H('التغيّر في النسبة')];
    const body = d.teachers.filter((t) => t.active).map((t, i) => {
      const cells: OutCell[] = [{ v: i + 1, s: 'num' }, { v: t.name, s: 'text' }, { v: t.subject_id ? d.subjectName(t.subject_id) : '', s: 'text' }];
      const pcts: (number | null)[] = [];
      for (const n of [1, 2]) {
        const v = d.visits.find((x) => x.teacher_id === t.id && x.visit_number === n);
        const tt = v && visitTotals(v, d.criteria);
        pcts.push(tt ? tt.pct : null);
        cells.push(v ? { v: excelDate(v.visit_date), s: 'date' } : { v: null, s: 'num' }, ...DOMAINS.map((dom): OutCell => ({ v: tt ? tt.domains[dom.id].weighted : null, s: 'num' })), { v: tt ? tt.raw : null, s: 'num' }, { v: tt ? tt.pct : null, s: 'total' });
      }
      cells.push({ v: pcts[0] != null && pcts[1] != null ? Math.round((pcts[1] - pcts[0]) * 100) / 100 : null, s: 'total' });
      return cells;
    });
    downloadBlob(await writeWorkbook([{ name: 'ملخص المعلمين', rows: [head, ...body], widths: [5, 36, 16, ...Array(13).fill(14)], freeze: { rows: 1, cols: 2 } }]), `ملخص-المعلمين-${todayISO()}.xlsx`);
  };
  const printAll = (variant: 'full' | 'short') => {
    setBulk(variant);
    toast('info', 'في نافذة الطباعة اختر الوجهة «حفظ بتنسيق PDF» لحفظ التقارير في ملف واحد.');
    setTimeout(() => { printWithTitle(`تقارير الزيارات الصفية ${todayISO()}`); }, 600);
  };

  const count = (s: ImportRow['status']) => (rows ?? []).filter((r) => r.status === s).length;

  return (
    <div>
      <div className="no-print">
        <PageHeader title="الاستيراد والتصدير" />
        <div className="grid gap-5 xl:grid-cols-2">
          <Card title="استيراد سجل التقييم من Excel" className="xl:col-span-2">
            <p className="text-muted leading-7 mb-4">اختر مصنف Excel الحالي (xlsx أو xlsm). تُقرأ ورقة «Evaluation» بأعمدتها نفسها: م، إسم المعلم (الزيارة 1)، التاريخ، المادة، الصف، ثم الدرجة المستحقة والوزن النسبي لكل معيار.</p>
            <input ref={input} type="file" accept=".xlsx,.xlsm" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
            <Button variant="primary" onClick={() => input.current?.click()}>اختيار ملف Excel</Button>

            {rows && rows.length > 0 && (
              <div className="mt-5">
                <p className="font-semibold mb-2">{fileName}</p>
                <p className="flex flex-wrap gap-2 mb-3"><Badge tone="good">جديدة: {count('new')}</Badge><Badge tone="warn">مسجلة مسبقاً: {count('exists')}</Badge><Badge tone="bad">فيها خطأ: {count('error')}</Badge></p>
                <div className="border border-line rounded-lg overflow-auto max-h-96">
                  <table className="w-full text-sm">
                    <thead className="bg-sunken sticky top-0 text-right"><tr><th className="px-3 py-2">الصف</th><th className="px-3 py-2">المعلم</th><th className="px-3 py-2">الزيارة</th><th className="px-3 py-2">التاريخ</th><th className="px-3 py-2">النسبة</th><th className="px-3 py-2">الحالة</th><th className="px-3 py-2">ملاحظات</th></tr></thead>
                    <tbody>
                      {rows.map((r) => (
                        <tr key={r.line} className="border-t border-line">
                          <td className="px-3 py-2 text-muted tnum">{r.line}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{r.teacherName}</td>
                          <td className="px-3 py-2 tnum">{r.visit?.visit_number ?? '—'}</td>
                          <td className="px-3 py-2 tnum whitespace-nowrap">{r.visit ? gregorian(r.visit.visit_date) : '—'}</td>
                          <td className="px-3 py-2 tnum font-semibold">{r.pct != null ? `${fmt(r.pct)}%` : '—'}</td>
                          <td className="px-3 py-2">{r.status === 'new' ? <Badge tone="good">جديدة</Badge> : r.status === 'exists' ? <Badge tone="warn">{replace ? 'ستُستبدل' : 'ستُتخطى'}</Badge> : <Badge tone="bad">خطأ</Badge>}</td>
                          <td className="px-3 py-2 text-muted">{r.note}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {count('exists') > 0 && <label className="flex items-center gap-2 mt-3"><input type="checkbox" className="w-5 h-5" checked={replace} onChange={(e) => setReplace(e.target.checked)} /> استبدال الزيارات المسجلة مسبقاً ببيانات الملف</label>}
                <div className="flex gap-2 mt-4">
                  <Button variant="primary" disabled={busy || toImport.length === 0} onClick={doImport}>{busy ? 'جارٍ الاستيراد…' : `استيراد ${toImport.length} زيارة`}</Button>
                  <Button onClick={() => setRows(null)} disabled={busy}>إلغاء</Button>
                </div>
              </div>
            )}
          </Card>

          <Card title="تصدير إلى Excel">
            <div className="space-y-3">
              <Row title="سجل التقييم" text="كل الزيارات بأعمدة ورقة Evaluation نفسها، ويمكن إعادة استيراده." action={<Button onClick={exportLog} disabled={!d.visits.length}>تصدير السجل</Button>} />
              <Row title="ملخص المعلمين" text="مجاميع المجالات والنسبة للزيارتين والتغيّر بينهما لكل معلم." action={<Button onClick={exportSummary}>تصدير الملخص</Button>} />
              <p className="text-sm text-muted">خطة الزيارات تُصدَّر من صفحة «خطة الزيارات».</p>
            </div>
          </Card>

          <Card title="تقارير PDF">
            <div className="space-y-3">
              <Row title="كل التقارير الكاملة" text={`${d.visits.length} تقرير بنموذج الأداة، كل زيارة في صفحتين.`} action={<Button onClick={() => printAll('full')} disabled={!d.visits.length}>طباعة / PDF</Button>} />
              <Row title="كل التقارير المختصرة" text="مجاميع المجالات فقط، صفحة لكل زيارة." action={<Button onClick={() => printAll('short')} disabled={!d.visits.length}>طباعة / PDF</Button>} />
              <p className="text-sm text-muted">تقرير زيارة واحدة يُطبع من صفحة الزيارة في سجل التقييم.</p>
            </div>
          </Card>
        </div>
      </div>

      {bulk && <div className="hidden print:block">{sortedVisits.map((v) => <ReportSheet key={v.id} visit={v} variant={bulk} />)}</div>}
    </div>
  );
}

function Row({ title, text, action }: { title: string; text: string; action: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border border-line rounded-lg p-3">
      <div><p className="font-semibold">{title}</p><p className="text-sm text-muted leading-6">{text}</p></div>
      <div className="shrink-0">{action}</div>
    </div>
  );
}
