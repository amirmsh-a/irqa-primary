import type { ReactNode } from 'react';
import { Badge, Button, Card, Empty, PageHeader } from '../components/ui';
import { fmt, scoreOf, visitTotals } from '../lib/calc';
import { DOMAINS, SCALE, type Visit } from '../lib/types';
import { cx, gregorian, hijri } from '../lib/util';
import { Link, navigate } from '../router';
import { useData, useStore } from '../store';
import { Delta } from './Teachers';

export default function TeacherProfile({ id, own }: { id: string; own?: boolean }) {
  const d = useData();
  const { isStaff } = useStore();
  const teacher = d.teacherById.get(id);
  if (!teacher) return <Empty title="المعلم غير موجود"><Link to="/teachers" className="text-brand underline">قائمة المعلمين</Link></Empty>;
  const v1 = d.visits.find((v) => v.teacher_id === id && v.visit_number === 1);
  const v2 = d.visits.find((v) => v.teacher_id === id && v.visit_number === 2);
  const t1 = v1 && visitTotals(v1, d.criteria);
  const t2 = v2 && visitTotals(v2, d.criteria);
  const both = !!(v1 && v2);

  const VisitCard = ({ n, v }: { n: 1 | 2; v?: Visit }) => {
    const t = v && visitTotals(v, d.criteria);
    return (
      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-semibold text-lg">الزيارة {n}</p>
            {v ? <p className="text-sm text-muted mt-1 leading-6">{gregorian(v.visit_date)}م — {hijri(v.visit_date)}<br />{d.subjectName(v.subject_id)}، {d.className(v.class_id)}{v.period ? `، الحصة ${v.period}` : ''}</p>
              : <p className="text-sm text-muted mt-1">لم تُنفَّذ بعد</p>}
          </div>
          {t && <p className="text-3xl font-bold text-brand tnum">{fmt(t.pct)}%</p>}
        </div>
        {v && t ? (
          <>
            <dl className="grid grid-cols-3 gap-2 mt-4 text-sm">
              {DOMAINS.map((dom) => (
                <div key={dom.id} className="bg-sunken rounded-lg px-2 py-2">
                  <dt className="text-muted text-xs leading-4 min-h-8">{dom.name}</dt>
                  <dd className="font-bold tnum">{fmt(t.domains[dom.id].weighted)} <span className="text-muted font-normal">/ {fmt(t.domains[dom.id].maxWeighted)}</span></dd>
                </div>
              ))}
            </dl>
            <div className="flex flex-wrap gap-2 mt-4">
              <Button small variant="primary" onClick={() => navigate(`/visits/${v.id}`)}>{own ? 'عرض التقرير وكتابة التأملات' : 'عرض التقرير والطباعة'}</Button>
              {isStaff && <Button small onClick={() => navigate(`/visits/${v.id}/edit`)}>تعديل</Button>}
            </div>
          </>
        ) : isStaff && (
          <div className="mt-4"><Button small variant="primary" onClick={() => navigate(`/visits/new?teacher=${id}&n=${n}`)}>تسجيل الزيارة {n}</Button></div>
        )}
      </Card>
    );
  };

  const th = 'px-3 py-2 font-semibold whitespace-nowrap';
  const td = 'px-3 py-2 border-t border-line text-center tnum';
  const label = (s?: number) => (s == null ? '—' : <><b>{s}</b> <span className="text-muted text-xs hidden sm:inline">{SCALE[s].label}</span></>);

  return (
    <div>
      <PageHeader title={teacher.name} sub={own ? 'زياراتي الصفية' : d.subjectName(teacher.subject_id)}
        actions={isStaff && <Button onClick={() => navigate('/teachers')}>كل المعلمين</Button>} />

      <div className="grid gap-4 md:grid-cols-2 mb-5">
        <VisitCard n={1} v={v1} />
        <VisitCard n={2} v={v2} />
      </div>

      {!v1 && !v2 ? (
        <Card><Empty title="لا توجد زيارات مسجلة لهذا المعلم بعد" /></Card>
      ) : (
        <Card title="مقارنة الزيارتين" actions={both && t1 && t2 ? <Badge tone={t2.pct - t1.pct > 0 ? 'good' : t2.pct - t1.pct < 0 ? 'bad' : 'neutral'}>النسبة: {fmt(t1.pct)}% ← {fmt(t2.pct)}%</Badge> : <Badge>تظهر المقارنة بعد تنفيذ الزيارتين</Badge>}>
          <div className="overflow-x-auto -mx-4">
            <table className="w-full text-sm min-w-[560px]">
              <thead className="bg-sunken">
                <tr><th className={cx(th, 'text-right')}>المعيار</th><th className={th}>الوزن</th><th className={th}>الزيارة 1</th><th className={th}>الزيارة 2</th><th className={th}>التغيّر</th></tr>
              </thead>
              <tbody>
                {DOMAINS.map((dom) => (
                  <DomainBlock key={dom.id}>
                    <tr className="bg-brand-soft text-brand font-bold">
                      <td className="px-3 py-2 border-t border-line">{dom.id}. {dom.name} <span className="font-normal text-xs">(مجموع الوزن)</span></td>
                      <td className={td}>{fmt((t1 ?? t2)!.domains[dom.id].maxWeighted)}</td>
                      <td className={td}>{t1 ? fmt(t1.domains[dom.id].weighted) : '—'}</td>
                      <td className={td}>{t2 ? fmt(t2.domains[dom.id].weighted) : '—'}</td>
                      <td className={td}><Delta value={t1 && t2 ? t2.domains[dom.id].weighted - t1.domains[dom.id].weighted : null} /></td>
                    </tr>
                    {d.criteria.filter((c) => c.domain === dom.id).map((c) => {
                      const s1 = v1 && scoreOf(v1, c.id); const s2 = v2 && scoreOf(v2, c.id);
                      const diff = s1 && s2 ? s2.score - s1.score : null;
                      return (
                        <tr key={c.id} className={cx(diff != null && diff > 0 && 'bg-good-soft/50', diff != null && diff < 0 && 'bg-bad-soft/50')}>
                          <td className="px-3 py-2 border-t border-line">{c.letter}. {c.title}</td>
                          <td className={cx(td, 'text-muted')}>{fmt((s2 ?? s1)?.weight ?? c.weight)}</td>
                          <td className={td}>{label(s1?.score)}</td>
                          <td className={td}>{label(s2?.score)}</td>
                          <td className={td}><Delta value={diff} /></td>
                        </tr>
                      );
                    })}
                  </DomainBlock>
                ))}
                <tr className="font-bold bg-sunken">
                  <td className="px-3 py-2.5 border-t border-line">إجمالي الدرجات (من 80)</td><td className={td} />
                  <td className={td}>{t1?.raw ?? '—'}</td><td className={td}>{t2?.raw ?? '—'}</td>
                  <td className={td}><Delta value={t1 && t2 ? t2.raw - t1.raw : null} /></td>
                </tr>
                <tr className="font-bold bg-sunken">
                  <td className="px-3 py-2.5 border-t border-line">النسبة الموزونة</td><td className={td} />
                  <td className={td}>{t1 ? `${fmt(t1.pct)}%` : '—'}</td><td className={td}>{t2 ? `${fmt(t2.pct)}%` : '—'}</td>
                  <td className={td}><Delta value={t1 && t2 ? t2.pct - t1.pct : null} suffix=" نقطة" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

const DomainBlock = ({ children }: { children: ReactNode }) => <>{children}</>;
