import { useEffect, useState } from 'react';
import ReportSheet from '../components/ReportSheet';
import { Button, Card, Confirm, Empty, Textarea } from '../components/ui';
import { api } from '../data';
import { cx } from '../lib/util';
import { Link, navigate } from '../router';
import { useData, useStore } from '../store';

export function printWithTitle(title: string) {
  const old = document.title;
  document.title = title;
  const restore = () => { document.title = old; window.removeEventListener('afterprint', restore); };
  window.addEventListener('afterprint', restore);
  window.print();
}

export default function VisitView({ id }: { id: string }) {
  const d = useData();
  const { isStaff, run, toast } = useStore();
  const visit = d.visits.find((v) => v.id === id);
  const [variant, setVariant] = useState<'full' | 'short'>('full');
  const [reflection, setReflection] = useState(visit?.teacher_reflection ?? '');
  const [confirm, setConfirm] = useState(false);
  useEffect(() => setReflection(visit?.teacher_reflection ?? ''), [visit?.teacher_reflection]);

  if (!visit) return <Empty title="الزيارة غير موجودة"><Link to="/" className="text-brand underline">العودة</Link></Empty>;
  const teacher = d.teacherName(visit.teacher_id);
  const title = `تقرير الزيارة ${visit.visit_number} - ${teacher}`;
  const dirty = reflection !== visit.teacher_reflection;

  return (
    <div>
      <div className="no-print flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h1 className="text-2xl font-bold">{teacher}</h1>
          <p className="text-muted">الزيارة {visit.visit_number}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="inline-flex rounded-lg border border-line overflow-hidden" role="tablist" aria-label="نوع التقرير">
            {(['full', 'short'] as const).map((v) => (
              <button key={v} type="button" role="tab" aria-selected={variant === v} onClick={() => setVariant(v)}
                className={cx('px-4 min-h-11 font-medium cursor-pointer', variant === v ? 'bg-brand text-on-brand' : 'bg-surface')}>
                {v === 'full' ? 'التقرير الكامل' : 'التقرير المختصر'}
              </button>
            ))}
          </div>
          <Button variant="primary" onClick={() => printWithTitle(title)}>طباعة</Button>
          <Button onClick={() => { toast('info', 'في نافذة الطباعة اختر الوجهة «حفظ بتنسيق PDF».'); setTimeout(() => printWithTitle(title), 400); }}>تصدير PDF</Button>
          {isStaff && <Button onClick={() => navigate(`/visits/${visit.id}/edit`)}>تعديل</Button>}
          {isStaff && <Button variant="ghost" className="text-bad" onClick={() => setConfirm(true)}>حذف</Button>}
        </div>
      </div>

      <Card title="تأملات المعلم ومرئياته وخطط التحسين" className="no-print mb-5">
        <Textarea value={reflection} onChange={(e) => setReflection(e.target.value)} rows={4} placeholder="اكتب تأملاتك حول الحصة وخطة التحسين…" />
        <div className="flex justify-end mt-3">
          <Button variant="primary" disabled={!dirty} onClick={() => run(() => api.setReflection(visit.id, reflection.trim()), 'تم حفظ التأملات')}>حفظ التأملات</Button>
        </div>
      </Card>

      <div className="overflow-x-auto pb-2">
        <div className="min-w-[720px] sm:min-w-0 [&_.sheet]:shadow-md [&_.sheet]:border [&_.sheet]:border-line">
          <ReportSheet visit={visit} variant={variant} />
        </div>
      </div>

      {confirm && (
        <Confirm title="حذف الزيارة" confirmLabel="حذف الزيارة" onClose={() => setConfirm(false)}
          text={<>سيُحذف تقييم الزيارة {visit.visit_number} للمعلم «{teacher}» نهائياً.</>}
          onConfirm={async () => { if (await run(() => api.deleteVisit(visit.id), 'تم حذف الزيارة')) navigate('/log'); }} />
      )}
    </div>
  );
}
