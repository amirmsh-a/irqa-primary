import { useMemo } from 'react';
import { Badge, Button, Card, Empty, Meter, PageHeader } from '../components/ui';
import { avg, fmt, round, scoreOf, visitTotals } from '../lib/calc';
import { DOMAINS } from '../lib/types';
import { cx, gregorian, todayISO } from '../lib/util';
import { Link, navigate } from '../router';
import { useData } from '../store';

/** صف في مخطط أعمدة أفقي: تسمية، شريط، قيمة */
function BarRow({ label, value, max = 100, suffix = '%', note, tone }: { label: string; value: number; max?: number; suffix?: string; note?: string; tone?: 'good' | 'bad' }) {
  return (
    <div className="grid grid-cols-[minmax(0,11rem)_1fr_auto] items-center gap-3 py-1.5">
      <span className="text-sm truncate" title={label}>{label}</span>
      <div className="h-3 rounded bg-sunken overflow-hidden">
        <div className={cx('h-full rounded', tone === 'good' ? 'bg-good' : tone === 'bad' ? 'bg-bad' : 'bg-brand')} style={{ width: `${Math.min(100, (value / max) * 100)}%` }} />
      </div>
      <span className="text-sm font-semibold tnum whitespace-nowrap">{fmt(value)}{suffix}{note && <span className="text-muted font-normal"> {note}</span>}</span>
    </div>
  );
}

export default function Dashboard() {
  const d = useData();
  const s = useMemo(() => {
    const active = d.teachers.filter((t) => t.active);
    const totals = d.visits.map((v) => ({ v, t: visitTotals(v, d.criteria) }));
    const done = (n: number) => new Set(d.visits.filter((v) => v.visit_number === n).map((v) => v.teacher_id)).size;
    const byKey = (key: (x: (typeof totals)[number]) => string | null, name: (id: string | null) => string) => {
      const m = new Map<string, number[]>();
      for (const x of totals) { const k = key(x); if (k) m.set(k, [...(m.get(k) ?? []), x.t.pct]); }
      return [...m].map(([id, xs]) => ({ id, name: name(id), avg: avg(xs), n: xs.length })).sort((a, b) => b.avg - a.avg);
    };
    const crit = d.criteria.map((c) => {
      const xs = d.visits.map((v) => scoreOf(v, c.id)?.score).filter((x): x is number => x != null);
      return { c, avg: avg(xs), n: xs.length };
    }).filter((x) => x.n);
    const ranked = [...crit].sort((a, b) => b.avg - a.avg);
    const today = todayISO();
    const overdue = d.schedule.flatMap((row) => ([1, 2] as const).flatMap((n) => {
      const date = n === 1 ? row.v1_date : row.v2_date;
      return date && date < today && !d.visits.some((v) => v.teacher_id === row.teacher_id && v.visit_number === n) ? [{ teacher_id: row.teacher_id, n, date }] : [];
    })).sort((a, b) => a.date.localeCompare(b.date));
    return {
      teachers: active.length, done1: done(1), done2: done(2),
      overall: avg(totals.map((x) => x.t.pct)),
      v1: avg(totals.filter((x) => x.v.visit_number === 1).map((x) => x.t.pct)),
      v2: avg(totals.filter((x) => x.v.visit_number === 2).map((x) => x.t.pct)),
      domains: DOMAINS.map((dom) => ({ ...dom, pct: avg(totals.map((x) => x.t.domains[dom.id].pct)), weighted: avg(totals.map((x) => x.t.domains[dom.id].weighted)), max: totals[0]?.t.domains[dom.id].maxWeighted ?? 0 })),
      top: ranked.slice(0, 3), bottom: ranked.slice(-3).reverse(), crit,
      subjects: byKey((x) => x.v.subject_id, d.subjectName), classes: byKey((x) => x.v.class_id, d.className),
      overdue,
      recent: [...totals].sort((a, b) => b.v.visit_date.localeCompare(a.v.visit_date)).slice(0, 5),
    };
  }, [d]);

  const Progress = ({ title, done }: { title: string; done: number }) => (
    <Card>
      <p className="text-muted text-sm">{title}</p>
      <p className="mt-1 text-3xl font-bold tnum">{done} <span className="text-base font-normal text-muted">من {s.teachers} معلماً</span></p>
      <div className="mt-3"><Meter pct={s.teachers ? (done / s.teachers) * 100 : 0} /></div>
      <p className="mt-2 text-sm text-muted">المتبقي: <b className="text-ink tnum">{Math.max(0, s.teachers - done)}</b></p>
    </Card>
  );

  return (
    <div>
      <PageHeader title="لوحة المعلومات" sub={`${d.settings.school} — ${d.settings.year}`}
        actions={<Button variant="primary" onClick={() => navigate('/visits/new')}>زيارة جديدة</Button>} />

      {s.overdue.length > 0 && (
        <div className="mb-5 rounded-xl border border-bad/30 bg-bad-soft text-bad px-4 py-3 flex flex-wrap items-center justify-between gap-2">
          <span><b>{s.overdue.length}</b> {s.overdue.length === 1 ? 'زيارة متأخرة' : 'زيارات متأخرة'} عن موعدها في الخطة، أقدمها للمعلم {d.teacherName(s.overdue[0].teacher_id)} ({gregorian(s.overdue[0].date)}).</span>
          <Link to="/schedule" className="underline font-semibold">فتح خطة الزيارات</Link>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-3 mb-5">
        <Progress title="الزيارة الأولى المنفذة" done={s.done1} />
        <Progress title="الزيارة الثانية المنفذة" done={s.done2} />
        <Card>
          <p className="text-muted text-sm">متوسط النسبة الموزونة العام</p>
          <p className="mt-1 text-3xl font-bold tnum text-brand">{d.visits.length ? `${fmt(s.overall)}%` : '—'}</p>
          <p className="mt-3 text-sm text-muted leading-7">
            الزيارة 1: <b className="text-ink tnum">{s.done1 ? `${fmt(s.v1)}%` : '—'}</b><br />
            الزيارة 2: <b className="text-ink tnum">{s.done2 ? `${fmt(s.v2)}%` : '—'}</b>
          </p>
        </Card>
      </div>

      {d.visits.length === 0 ? (
        <Card><Empty title="لا توجد زيارات مسجلة بعد">
          ابدأ بتسجيل <Link to="/visits/new" className="text-brand underline">زيارة جديدة</Link>، أو استورد السجل الحالي من <Link to="/data" className="text-brand underline">ملف Excel</Link>.
        </Empty></Card>
      ) : (
        <div className="grid gap-5 xl:grid-cols-2">
          <Card title="متوسط المجالات">
            {s.domains.map((dom) => <BarRow key={dom.id} label={dom.name} value={dom.pct} note={`(${fmt(dom.weighted)} / ${fmt(dom.max)})`} />)}
            <p className="text-xs text-muted mt-2">النسبة = متوسط مجموع الوزن في المجال ÷ الحد الأعلى للمجال.</p>
          </Card>

          <Card title="أعلى المعايير وأدناها">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-sm font-semibold text-good mb-2">الأعلى متوسطاً</p>
                {s.top.map((x) => <p key={x.c.id} className="flex justify-between gap-2 py-1.5 border-b border-line last:border-0 text-sm"><span>{x.c.title}</span><b className="tnum whitespace-nowrap">{fmt(x.avg)} / 4</b></p>)}
              </div>
              <div>
                <p className="text-sm font-semibold text-bad mb-2">الأدنى متوسطاً</p>
                {s.bottom.map((x) => <p key={x.c.id} className="flex justify-between gap-2 py-1.5 border-b border-line last:border-0 text-sm"><span>{x.c.title}</span><b className="tnum whitespace-nowrap">{fmt(x.avg)} / 4</b></p>)}
              </div>
            </div>
          </Card>

          <Card title="متوسط النسبة حسب المادة">
            {s.subjects.length ? s.subjects.map((x) => <BarRow key={x.id} label={x.name} value={x.avg} note={`(${x.n})`} />) : <p className="text-muted text-sm">لم تُحدد المادة في الزيارات المسجلة.</p>}
            <p className="text-xs text-muted mt-2">الرقم بين القوسين عدد الزيارات.</p>
          </Card>

          <Card title="متوسط النسبة حسب الصف">
            <div className="max-h-80 overflow-y-auto pe-1">
              {s.classes.length ? s.classes.map((x) => <BarRow key={x.id} label={x.name} value={x.avg} note={`(${x.n})`} />) : <p className="text-muted text-sm">لم يُحدد الصف في الزيارات المسجلة.</p>}
            </div>
          </Card>

          <Card title="متوسط الدرجة لكل معيار (من 4)" className="xl:col-span-2">
            <div className="grid gap-x-8 gap-y-4 lg:grid-cols-3">
              {DOMAINS.map((dom) => (
                <div key={dom.id}>
                  <p className="font-semibold text-brand mb-1">{dom.name}</p>
                  {s.crit.filter((x) => x.c.domain === dom.id).map((x) => (
                    <BarRow key={x.c.id} label={x.c.title} value={x.avg} max={4} suffix="" tone={s.top.includes(x) ? 'good' : s.bottom.includes(x) ? 'bad' : undefined} />
                  ))}
                </div>
              ))}
            </div>
            <p className="text-xs text-muted mt-3">الأخضر: أعلى ثلاثة معايير، والأحمر: أدنى ثلاثة.</p>
          </Card>

          <Card title="آخر الزيارات" className="xl:col-span-2" actions={<Link to="/log" className="text-brand underline text-sm">السجل الكامل</Link>}>
            <ul className="divide-y divide-line">
              {s.recent.map(({ v, t }) => (
                <li key={v.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                  <Link to={`/visits/${v.id}`} className="font-medium hover:text-brand hover:underline">{d.teacherName(v.teacher_id)}</Link>
                  <span className="flex items-center gap-3 text-sm text-muted">
                    <Badge tone={v.visit_number === 1 ? 'brand' : 'good'}>الزيارة {v.visit_number}</Badge>
                    <span>{d.subjectName(v.subject_id)}</span>
                    <span className="tnum">{gregorian(v.visit_date)}</span>
                    <b className="text-ink tnum">{fmt(round(t.pct))}%</b>
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}
    </div>
  );
}
