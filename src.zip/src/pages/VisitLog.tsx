import { useMemo, useState, type ReactNode } from 'react';
import { Badge, Button, Card, Confirm, Empty, Input, PageHeader, Select } from '../components/ui';
import { api } from '../data';
import { fmt, scoreOf, visitTotals } from '../lib/calc';
import { buildLogSheet } from '../lib/evaluation';
import { DOMAINS, type Visit } from '../lib/types';
import { cx, downloadBlob, gregorian, hijri, norm, todayISO } from '../lib/util';
import { writeWorkbook } from '../lib/xlsx';
import { Link, navigate } from '../router';
import { useData, useStore } from '../store';

type SortKey = 'teacher' | 'n' | 'date' | 'subject' | 'class' | 'd1' | 'd2' | 'd3' | 'raw' | 'pct';

export default function VisitLog() {
  const d = useData();
  const { run, data } = useStore();
  const [q, setQ] = useState('');
  const [f, setF] = useState({ teacher: '', subject: '', klass: '', n: '', from: '', to: '' });
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: 'date', dir: -1 });
  const [detail, setDetail] = useState(true);
  const [del, setDel] = useState<Visit | null>(null);

  const rows = useMemo(() => {
    const nq = norm(q);
    const list = d.visits
      .filter((v) => !f.teacher || v.teacher_id === f.teacher)
      .filter((v) => !f.subject || v.subject_id === f.subject)
      .filter((v) => !f.klass || v.class_id === f.klass)
      .filter((v) => !f.n || String(v.visit_number) === f.n)
      .filter((v) => !f.from || v.visit_date >= f.from)
      .filter((v) => !f.to || v.visit_date <= f.to)
      .map((v) => ({ v, t: visitTotals(v, d.criteria), teacher: d.teacherName(v.teacher_id), subject: d.subjectName(v.subject_id), klass: d.className(v.class_id) }))
      .filter((r) => !nq || norm(`${r.teacher} ${r.subject} ${r.klass}`).includes(nq));
    const val = (r: (typeof list)[number]): string | number => {
      switch (sort.key) {
        case 'teacher': return r.teacher;
        case 'n': return r.v.visit_number;
        case 'date': return r.v.visit_date;
        case 'subject': return r.subject;
        case 'class': return r.klass;
        case 'd1': return r.t.domains[1].weighted;
        case 'd2': return r.t.domains[2].weighted;
        case 'd3': return r.t.domains[3].weighted;
        case 'raw': return r.t.raw;
        default: return r.t.pct;
      }
    };
    return list.sort((a, b) => {
      const x = val(a), y = val(b);
      const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'ar');
      return c * sort.dir || a.teacher.localeCompare(b.teacher, 'ar');
    });
  }, [d, q, f, sort]);

  const Th = ({ k, children, className, rowSpan }: { k: SortKey; children: string; className?: string; rowSpan?: number }) => (
    <th rowSpan={rowSpan} className={cx('px-2 py-2 font-semibold whitespace-nowrap', className)} aria-sort={sort.key === k ? (sort.dir === 1 ? 'ascending' : 'descending') : undefined}>
      <button type="button" className="inline-flex items-center gap-1 cursor-pointer hover:text-brand" onClick={() => setSort((s) => ({ key: k, dir: s.key === k ? (s.dir === 1 ? -1 : 1) : 1 }))}>
        {children}<span className="text-xs w-3">{sort.key === k ? (sort.dir === 1 ? '▲' : '▼') : ''}</span>
      </button>
    </th>
  );

  const exportExcel = async () => {
    const blob = await writeWorkbook([buildLogSheet(data!, rows.map((r) => r.v))]);
    downloadBlob(blob, `سجل-التقييم-${todayISO()}.xlsx`);
  };
  const filtered = q || Object.values(f).some(Boolean);
  const cell = 'px-2 py-2 border-t border-line text-center tnum whitespace-nowrap';

  return (
    <div>
      <PageHeader title="سجل التقييم" sub={`${rows.length} من ${d.visits.length} زيارة`}
        actions={<>
          <Button onClick={() => setDetail((x) => !x)}>{detail ? 'إخفاء درجات المعايير' : 'إظهار درجات المعايير'}</Button>
          <Button onClick={exportExcel} disabled={!rows.length}>تصدير Excel</Button>
          <Button variant="primary" onClick={() => navigate('/visits/new')}>زيارة جديدة</Button>
        </>} />

      <Card className="mb-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Input className="sm:col-span-2" placeholder="بحث باسم المعلم أو المادة أو الصف…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="بحث" />
          <Select value={f.teacher} onChange={(e) => setF({ ...f, teacher: e.target.value })} aria-label="المعلم">
            <option value="">كل المعلمين</option>
            {d.teachers.filter((t) => d.visits.some((v) => v.teacher_id === t.id)).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
          <Select value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} aria-label="المادة">
            <option value="">كل المواد</option>
            {d.subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
          <Select value={f.klass} onChange={(e) => setF({ ...f, klass: e.target.value })} aria-label="الصف">
            <option value="">كل الصفوف</option>
            {d.classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Select value={f.n} onChange={(e) => setF({ ...f, n: e.target.value })} aria-label="رقم الزيارة">
            <option value="">الزيارتان</option><option value="1">الزيارة 1</option><option value="2">الزيارة 2</option>
          </Select>
          <label className="flex items-center gap-2 text-sm text-muted whitespace-nowrap">من
            <Input type="date" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} aria-label="من تاريخ" />
          </label>
          <label className="flex items-center gap-2 text-sm text-muted whitespace-nowrap">إلى
            <Input type="date" value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} aria-label="إلى تاريخ" />
          </label>
        </div>
        {filtered && <button type="button" className="mt-3 text-sm text-brand underline cursor-pointer" onClick={() => { setQ(''); setF({ teacher: '', subject: '', klass: '', n: '', from: '', to: '' }); }}>مسح عوامل التصفية</button>}
      </Card>

      {rows.length === 0 ? (
        <Card><Empty title={d.visits.length ? 'لا توجد زيارات مطابقة' : 'لا توجد زيارات مسجلة بعد'}>
          {d.visits.length ? 'غيّر عوامل التصفية أو امسحها.' : <>سجّل أول زيارة من <Link to="/visits/new" className="text-brand underline">زيارة جديدة</Link> أو استورد السجل من <Link to="/data" className="text-brand underline">ملف Excel</Link>.</>}
        </Empty></Card>
      ) : (
        <div className="bg-surface border border-line rounded-xl overflow-auto max-h-[75vh]">
          <table className="text-sm border-separate border-spacing-0 min-w-full">
            <thead className="sticky top-0 z-20 bg-sunken">
              <tr>
                <th rowSpan={3} className="px-2 py-2 font-semibold">م</th>
                <Th k="teacher" rowSpan={3} className="sticky right-0 bg-sunken z-10 text-right min-w-44">إسم المعلم</Th>
                <Th k="n" rowSpan={3}>الزيارة</Th>
                <Th k="date" rowSpan={3}>التاريخ</Th>
                <Th k="subject" rowSpan={3}>المادة</Th>
                <Th k="class" rowSpan={3}>الصف</Th>
                {DOMAINS.map((dom) => {
                  const n = d.criteria.filter((c) => c.domain === dom.id).length;
                  return <th key={dom.id} colSpan={(detail ? n * 2 : 0) + 2} className="px-2 py-2 font-semibold border-r border-line whitespace-nowrap">{dom.name}</th>;
                })}
                <th colSpan={2} className="px-2 py-2 font-semibold border-r border-line">الإجمالي</th>
                <th rowSpan={3} className="px-2 py-2 font-semibold border-r border-line">إجراءات</th>
              </tr>
              <tr>
                {DOMAINS.map((dom) => (
                  <FragmentCols key={dom.id}>
                    {detail && d.criteria.filter((c) => c.domain === dom.id).map((c) => (
                      <th key={c.id} colSpan={2} className="px-2 py-1 font-medium text-xs border-r border-t border-line min-w-28 max-w-40 leading-4" title={c.description}>{c.title}</th>
                    ))}
                    <th colSpan={2} className="px-2 py-1 font-medium text-xs border-r border-t border-line whitespace-nowrap">المجموع</th>
                  </FragmentCols>
                ))}
                <th colSpan={2} className="border-r border-t border-line" />
              </tr>
              <tr className="text-xs text-muted">
                {DOMAINS.map((dom, i) => (
                  <FragmentCols key={dom.id}>
                    {detail && d.criteria.filter((c) => c.domain === dom.id).map((c) => (
                      <FragmentCols key={c.id}><th className="px-1 py-1 font-normal border-r border-t border-line">الدرجة</th><th className="px-1 py-1 font-normal border-t border-line">الوزن</th></FragmentCols>
                    ))}
                    <Th k={(['d1', 'd2', 'd3'] as const)[i]} className="border-r border-t border-line font-normal !py-1">الدرجات</Th>
                    <Th k={(['d1', 'd2', 'd3'] as const)[i]} className="border-t border-line font-normal !py-1">الوزن</Th>
                  </FragmentCols>
                ))}
                <Th k="raw" className="border-r border-t border-line font-normal !py-1">الدرجات</Th>
                <Th k="pct" className="border-t border-line font-normal !py-1">النسبة</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.v.id} className="hover:bg-brand-soft/40">
                  <td className={cx(cell, 'text-muted')}>{i + 1}</td>
                  <td className="px-2 py-2 border-t border-line sticky right-0 bg-surface z-10 font-medium whitespace-nowrap">
                    <Link to={`/teachers/${r.v.teacher_id}`} className="hover:text-brand hover:underline">{r.teacher}</Link>
                  </td>
                  <td className={cell}><Badge tone={r.v.visit_number === 1 ? 'brand' : 'good'}>الزيارة {r.v.visit_number}</Badge></td>
                  <td className={cell} title={hijri(r.v.visit_date)}>{gregorian(r.v.visit_date)}<span className="block text-xs text-muted">{hijri(r.v.visit_date)}</span></td>
                  <td className={cell}>{r.subject}</td>
                  <td className={cell}>{r.klass}</td>
                  {DOMAINS.map((dom) => (
                    <FragmentCols key={dom.id}>
                      {detail && d.criteria.filter((c) => c.domain === dom.id).map((c) => {
                        const s = scoreOf(r.v, c.id);
                        return <FragmentCols key={c.id}><td className={cx(cell, 'border-r')}>{s?.score ?? '—'}</td><td className={cx(cell, 'text-muted')}>{s ? fmt(s.score * s.weight) : '—'}</td></FragmentCols>;
                      })}
                      <td className={cx(cell, 'border-r bg-sunken/60 font-semibold')}>{r.t.domains[dom.id].raw}</td>
                      <td className={cx(cell, 'bg-sunken/60 font-semibold')}>{fmt(r.t.domains[dom.id].weighted)}</td>
                    </FragmentCols>
                  ))}
                  <td className={cx(cell, 'border-r font-bold')}>{r.t.raw}</td>
                  <td className={cx(cell, 'font-bold text-brand')}>{fmt(r.t.pct)}%</td>
                  <td className={cx(cell, 'border-r')}>
                    <div className="flex gap-1 justify-center">
                      <Button small onClick={() => navigate(`/visits/${r.v.id}`)}>عرض وطباعة</Button>
                      <Button small onClick={() => navigate(`/visits/${r.v.id}/edit`)}>تعديل</Button>
                      <Button small variant="ghost" className="text-bad" onClick={() => setDel(r.v)}>حذف</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {del && (
        <Confirm title="حذف الزيارة" confirmLabel="حذف الزيارة" onClose={() => setDel(null)}
          text={<>سيُحذف تقييم الزيارة {del.visit_number} للمعلم «{d.teacherName(del.teacher_id)}» نهائياً.</>}
          onConfirm={() => run(() => api.deleteVisit(del.id), 'تم حذف الزيارة')} />
      )}
    </div>
  );
}

const FragmentCols = ({ children }: { children: ReactNode }) => <>{children}</>;
