import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../data';
import { Button, Card, Combobox, Field, Input, PageHeader, Select, Textarea, Badge } from '../components/ui';
import { computeTotals, fmt } from '../lib/calc';
import { DOMAINS, PERIODS, SCALE, type Visit } from '../lib/types';
import { cx, hijri, todayISO, uid, dayName } from '../lib/util';
import { navigate, query, usePath } from '../router';
import { useData, useStore } from '../store';

interface FormState {
  teacher_id: string; visit_number: 1 | 2; visit_date: string; subject_id: string; class_id: string; period: string;
  scores: Record<string, number>; observer_feedback: string; teacher_reflection: string;
}
const blank = (): FormState => ({
  teacher_id: '', visit_number: 1, visit_date: todayISO(), subject_id: '', class_id: '', period: '',
  scores: {}, observer_feedback: '', teacher_reflection: '',
});

const scaleOn = ['bg-s0 border-s0', 'bg-s1 border-s1', 'bg-s2 border-s2', 'bg-s3 border-s3', 'bg-s4 border-s4'];
const scaleText = ['text-s0', 'text-s1', 'text-s2', 'text-s3', 'text-s4'];

export default function VisitForm({ editId }: { editId?: string }) {
  const d = useData();
  const { user, run, toast, isAdmin } = useStore();
  const path = usePath();
  const editing = editId ? d.visits.find((v) => v.id === editId) : undefined;
  const draftKey = `ziyarat.draft.${user?.id ?? 'x'}`;

  const [restored, setRestored] = useState(false);
  const [form, setForm] = useState<FormState>(() => {
    if (editing) {
      return {
        teacher_id: editing.teacher_id, visit_number: editing.visit_number, visit_date: editing.visit_date,
        subject_id: editing.subject_id ?? '', class_id: editing.class_id ?? '', period: editing.period ? String(editing.period) : '',
        scores: Object.fromEntries(editing.scores.map((s) => [s.criterion_id, s.score])),
        observer_feedback: editing.observer_feedback, teacher_reflection: editing.teacher_reflection,
      };
    }
    const q = query(path);
    if (!q.get('teacher')) {
      try {
        const raw = localStorage.getItem(draftKey);
        if (raw) {
          const saved = JSON.parse(raw) as FormState;
          if (saved.teacher_id || Object.keys(saved.scores ?? {}).length || saved.observer_feedback) return { ...blank(), ...saved };
        }
      } catch { /* تجاهل */ }
    }
    return blank();
  });
  const [showMissing, setShowMissing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string>('');
  const firstRender = useRef(true);

  // أوزان الزيارة: عند التعديل نُبقي الأوزان المحفوظة مع الزيارة
  const weightOf = useMemo(() => {
    const saved = new Map(editing?.scores.map((s) => [s.criterion_id, s.weight]));
    return (id: string, current: number) => saved.get(id) ?? current;
  }, [editing]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setForm((f) => ({ ...f, [k]: v }));

  const visitsOf = (teacherId: string) => d.visits.filter((v) => v.teacher_id === teacherId && v.id !== editId);
  const taken = (n: 1 | 2) => visitsOf(form.teacher_id).some((v) => v.visit_number === n);

  const pickTeacher = (id: string, preferred?: 1 | 2) => {
    const t = d.teacherById.get(id);
    const done = visitsOf(id).map((v) => v.visit_number);
    const n: 1 | 2 = preferred ?? (done.includes(1) && !done.includes(2) ? 2 : 1);
    const plan = d.schedule.find((s) => s.teacher_id === id);
    setForm((f) => ({
      ...f, teacher_id: id, visit_number: n,
      subject_id: t?.subject_id ?? f.subject_id,
      class_id: (n === 1 ? plan?.v1_class_id : plan?.v2_class_id) ?? f.class_id,
      period: String((n === 1 ? plan?.v1_period : plan?.v2_period) ?? f.period ?? ''),
    }));
  };

  // فتح النموذج من الخطة أو ملف المعلم: ‎/visits/new?teacher=..&n=2
  useEffect(() => {
    if (editing) return;
    const q = query(path);
    const t = q.get('teacher');
    if (t && d.teacherById.has(t)) pickTeacher(t, q.get('n') === '2' ? 2 : q.get('n') === '1' ? 1 : undefined);
    else if (form.teacher_id || Object.keys(form.scores).length) setRestored(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // حفظ المسودة تلقائياً أثناء التعبئة (للزيارة الجديدة)
  useEffect(() => {
    if (editing) return;
    if (firstRender.current) { firstRender.current = false; return; }
    const h = setTimeout(() => {
      try {
        localStorage.setItem(draftKey, JSON.stringify(form));
        setSavedAt(new Date().toLocaleTimeString('ar-EG-u-nu-latn', { hour: '2-digit', minute: '2-digit' }));
      } catch { /* تجاهل */ }
    }, 500);
    return () => clearTimeout(h);
  }, [form, editing, draftKey]);

  const clearDraft = () => { try { localStorage.removeItem(draftKey); } catch { /* تجاهل */ } };
  const reset = () => { clearDraft(); setForm(blank()); setShowMissing(false); setRestored(false); setSavedAt(''); };

  const scores = d.criteria.filter((c) => form.scores[c.id] != null).map((c) => ({ criterion_id: c.id, score: form.scores[c.id], weight: weightOf(c.id, c.weight) }));
  const full = d.criteria.map((c) => ({ criterion_id: c.id, score: 4, weight: weightOf(c.id, c.weight) }));
  const totals = computeTotals(scores, d.criteria);
  const max = computeTotals(full, d.criteria);
  const missing = d.criteria.filter((c) => form.scores[c.id] == null);
  // النسبة تُحسب من كامل الأوزان حتى أثناء التعبئة
  const pct = max.maxWeighted ? Math.round((totals.weighted / max.maxWeighted) * 10000) / 100 : 0;

  const submit = async () => {
    if (!form.teacher_id) { toast('error', 'اختر اسم المعلم أولاً.'); return; }
    if (!form.visit_date) { toast('error', 'حدد تاريخ الزيارة.'); return; }
    if (taken(form.visit_number)) { toast('error', `الزيارة ${form.visit_number} مسجلة مسبقاً لهذا المعلم.`); return; }
    if (missing.length) {
      setShowMissing(true);
      const k = missing.length;
      toast('error', `لا يمكن الحفظ: ${k === 1 ? 'معيار واحد لم يُقيَّم' : k === 2 ? 'معياران لم يُقيَّما' : k <= 10 ? `${k} معايير لم تُقيَّم` : `${k} معياراً لم يُقيَّم`} بعد.`);
      document.getElementById(`crit-${missing[0].id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    const visit: Visit = {
      id: editing?.id ?? uid(),
      teacher_id: form.teacher_id, visit_number: form.visit_number, visit_date: form.visit_date,
      subject_id: form.subject_id || null, class_id: form.class_id || null, period: form.period ? Number(form.period) : null,
      observer_name: editing?.observer_name || (isAdmin ? d.settings.observer : user?.full_name || d.settings.observer),
      observer_feedback: form.observer_feedback.trim(), teacher_reflection: form.teacher_reflection.trim(),
      scores,
    };
    setSaving(true);
    const ok = await run(async () => {
      await api.saveVisit(visit);
      // إذا لم تكن للمعلم مادة محفوظة نحفظها لتُعبَّأ تلقائياً في المرة القادمة
      const t = d.teacherById.get(visit.teacher_id);
      if (t && !t.subject_id && visit.subject_id) await api.saveTeacher({ ...t, subject_id: visit.subject_id }).catch(() => undefined);
    }, editing ? 'تم حفظ التعديلات' : 'تم حفظ الزيارة في سجل التقييم');
    setSaving(false);
    if (!ok) return;
    if (editing) navigate(`/visits/${visit.id}`);
    else { reset(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  };

  const teacherOptions = d.teachers
    .filter((t) => t.active || t.id === form.teacher_id)
    .map((t) => {
      const n = d.visits.filter((v) => v.teacher_id === t.id).length;
      return { id: t.id, label: t.name, hint: n === 2 ? 'اكتملت الزيارتان' : n === 1 ? 'زيارة واحدة' : '' };
    });

  return (
    <div>
      <PageHeader
        title={editing ? 'تعديل الزيارة' : 'زيارة جديدة'}
        sub={editing ? d.teacherName(editing.teacher_id) : 'أداة معارف للملاحظة الصفية'}
        actions={!editing && <Button onClick={reset}>مسح النموذج</Button>}
      />

      {restored && !editing && (
        <div className="mb-4 rounded-lg bg-brand-soft text-brand px-4 py-3 flex flex-wrap items-center justify-between gap-2">
          <span>استُعيدت مسودة محفوظة تلقائياً من آخر جلسة.</span>
          <button type="button" className="underline font-medium cursor-pointer" onClick={reset}>تجاهل المسودة والبدء من جديد</button>
        </div>
      )}

      <Card title="بيانات الزيارة" className="mb-5">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          <Field label="اسم المعلم" className="sm:col-span-2 xl:col-span-1">
            <Combobox options={teacherOptions} value={form.teacher_id} onChange={(id) => pickTeacher(id)} placeholder="ابحث باسم المعلم…" disabled={!!editing} />
          </Field>
          <div>
            <span className="block text-sm font-medium text-muted mb-1">رقم الزيارة</span>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="رقم الزيارة">
              {([1, 2] as const).map((n) => {
                const isTaken = !!form.teacher_id && taken(n);
                return (
                  <button key={n} type="button" role="radio" aria-checked={form.visit_number === n} disabled={isTaken}
                    onClick={() => set('visit_number', n)}
                    className={cx('min-h-11 rounded-lg border font-medium cursor-pointer disabled:cursor-not-allowed',
                      form.visit_number === n && !isTaken ? 'bg-brand text-on-brand border-brand' : 'bg-surface border-line',
                      isTaken && 'opacity-60')}>
                    الزيارة {n}{isTaken && ' (مسجلة)'}
                  </button>
                );
              })}
            </div>
          </div>
          <Field label="التاريخ" hint={form.visit_date ? `${dayName(form.visit_date)} · ${hijri(form.visit_date)}` : undefined}>
            <Input type="date" value={form.visit_date} onChange={(e) => set('visit_date', e.target.value)} />
          </Field>
          <Field label="المادة">
            <Select value={form.subject_id} onChange={(e) => set('subject_id', e.target.value)}>
              <option value="">— اختر —</option>
              {d.subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الصف">
              <Select value={form.class_id} onChange={(e) => set('class_id', e.target.value)}>
                <option value="">— اختر —</option>
                {d.classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </Field>
            <Field label="الحصة">
              <Select value={form.period} onChange={(e) => set('period', e.target.value)}>
                <option value="">—</option>
                {PERIODS.map((p) => <option key={p} value={p}>{p}</option>)}
              </Select>
            </Field>
          </div>
        </div>
      </Card>

      {DOMAINS.map((dom) => {
        const list = d.criteria.filter((c) => c.domain === dom.id);
        const t = totals.domains[dom.id]; const m = max.domains[dom.id];
        return (
          <section key={dom.id} className="mb-6">
            <header className="flex flex-wrap items-baseline justify-between gap-2 border-b-2 border-brand pb-2 mb-3">
              <h2 className="text-xl font-bold text-brand">{dom.id}. {dom.name}</h2>
              <p className="text-sm text-muted tnum">مجموع الدرجات <b className="text-ink">{t.raw}</b> / {m.maxRaw} · مجموع الوزن <b className="text-ink">{fmt(t.weighted)}</b> / {fmt(m.maxWeighted)}</p>
            </header>
            <div className="space-y-3">
              {list.map((c) => {
                const val = form.scores[c.id];
                const w = weightOf(c.id, c.weight);
                const isMissing = showMissing && val == null;
                return (
                  <article key={c.id} id={`crit-${c.id}`} className={cx('bg-surface border rounded-xl p-4', isMissing ? 'border-bad ring-2 ring-bad/20' : 'border-line')}>
                    <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-1">
                      <h3 className="font-semibold text-base leading-7">{c.letter}. {c.title}</h3>
                      <p className="text-sm text-muted tnum whitespace-nowrap">
                        الوزن {fmt(w)}
                        {val != null && <> · الوزن النسبي <b className={scaleText[val]}>{fmt(val * w)}</b></>}
                      </p>
                    </div>
                    <p className="text-sm text-muted leading-6 mt-1 mb-3 max-w-4xl">{c.description}</p>
                    <div className="grid grid-cols-5 gap-1.5 sm:gap-2" role="radiogroup" aria-label={c.title}>
                      {SCALE.map((s) => {
                        const on = val === s.value;
                        return (
                          <button key={s.value} type="button" role="radio" aria-checked={on}
                            onClick={() => setForm((f) => ({ ...f, scores: { ...f.scores, [c.id]: s.value } }))}
                            className={cx('rounded-lg border px-1 py-2 min-h-[3.75rem] flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors',
                              on ? cx(scaleOn[s.value], 'text-white dark:text-black') : 'bg-surface border-line hover:bg-sunken')}>
                            <span className="text-lg font-bold tnum leading-none">{s.value}</span>
                            <span className="text-[11px] sm:text-sm leading-tight text-center">{s.label}</span>
                          </button>
                        );
                      })}
                    </div>
                    {isMissing && <p className="text-bad text-sm mt-2">اختر تقديراً لهذا المعيار.</p>}
                  </article>
                );
              })}
            </div>
          </section>
        );
      })}

      <div className="grid gap-4 lg:grid-cols-2 mb-6">
        <Field label="التغذية الراجعة ومرئيات الملاحظ">
          <Textarea value={form.observer_feedback} onChange={(e) => set('observer_feedback', e.target.value)} rows={5} />
        </Field>
        <Field label="تأملات المعلم ومرئياته وخطط التحسين">
          <Textarea value={form.teacher_reflection} onChange={(e) => set('teacher_reflection', e.target.value)} rows={5} />
        </Field>
      </div>

      {/* الشريط الثابت: المجاميع أثناء التعبئة */}
      <div className="sticky bottom-[calc(3.6rem+env(safe-area-inset-bottom))] lg:bottom-3 z-30 bg-surface border border-line rounded-xl shadow-lg px-3 py-2.5 sm:px-4 sm:py-3">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <div className="grid grid-cols-3 gap-x-4 gap-y-1 flex-1 min-w-[260px] text-xs sm:text-sm">
            {DOMAINS.map((dom) => (
              <div key={dom.id} className="min-w-0">
                <p className="text-muted truncate">{dom.name}</p>
                <p className="font-bold tnum">{fmt(totals.domains[dom.id].weighted)} <span className="text-muted font-normal">/ {fmt(max.domains[dom.id].maxWeighted)}</span></p>
              </div>
            ))}
          </div>
          <div className="text-xs sm:text-sm">
            <p className="text-muted">إجمالي الدرجات</p>
            <p className="font-bold tnum">{totals.raw} <span className="text-muted font-normal">/ {max.maxRaw}</span></p>
          </div>
          <div>
            <p className="text-xs sm:text-sm text-muted">النسبة الموزونة</p>
            <p className="text-2xl font-bold text-brand tnum leading-none">{fmt(pct)}%</p>
          </div>
          <div className="flex items-center gap-3 ms-auto">
            <div className="text-xs text-muted text-left leading-5">
              {missing.length ? <Badge tone="warn">متبقٍّ {missing.length} من {d.criteria.length}</Badge> : <Badge tone="good">اكتمل التقييم</Badge>}
              {savedAt && !editing && <p className="hidden sm:block">حُفظت المسودة {savedAt}</p>}
            </div>
            <Button variant="primary" onClick={submit} disabled={saving} className="px-7">{saving ? 'جارٍ الحفظ…' : editing ? 'حفظ التعديلات' : 'إرسال'}</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
