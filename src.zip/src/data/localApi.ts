import type { AppData, Invite, Profile } from '../lib/types';
import { norm, uid } from '../lib/util';
import { AppError, type Api } from './api';
import { buildSeed } from './seed';

/**
 * نسخة محلية للتجربة: تحفظ كل شيء في متصفح هذا الجهاز فقط (localStorage).
 * تُستخدم تلقائياً عند عدم ضبط بيانات Supabase في ملف .env
 */
const DB_KEY = 'ziyarat.db.v1';
const SESSION_KEY = 'ziyarat.session.v1';

interface LocalUser extends Profile { pass: string }
interface Db extends AppData { users: LocalUser[] }

let mem: Db | null = null;
function read(): Db {
  if (mem) return mem;
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) return (mem = JSON.parse(raw) as Db);
  } catch { /* التخزين غير متاح: نكمل في الذاكرة */ }
  mem = { ...buildSeed(), users: [] };
  write(mem);
  return mem;
}
function write(db: Db) {
  mem = db;
  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch { /* تجاهل */ }
}

async function hash(s: string): Promise<string> {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('ziyarat:' + s));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 5381;
    for (const ch of s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0;
    return 'x' + (h >>> 0).toString(16);
  }
}
const strip = ({ pass: _p, ...u }: LocalUser): Profile => u;

function upsert<T>(list: T[], item: T, key: (x: T) => string): T[] {
  const i = list.findIndex((x) => key(x) === key(item));
  if (i === -1) return [...list, item];
  const copy = list.slice(); copy[i] = item; return copy;
}
function uniqueName(list: { id: string; name: string }[], item: { id: string; name: string }) {
  if (list.some((x) => x.id !== item.id && norm(x.name) === norm(item.name))) throw new AppError('هذا الاسم موجود مسبقاً.');
}

export const localApi: Api = {
  mode: 'local',

  async getSession() {
    let id: string | null = null;
    try { id = localStorage.getItem(SESSION_KEY); } catch { /* تجاهل */ }
    const u = read().users.find((x) => x.id === id);
    return u ? strip(u) : null;
  },
  async needsSetup() { return !read().users.some((u) => u.role === 'admin'); },
  async createAdmin(email, password, fullName) {
    const db = read();
    if (db.users.some((u) => u.role === 'admin')) throw new AppError('يوجد مدير للنظام مسبقاً.');
    if (password.length < 6) throw new AppError('كلمة المرور قصيرة. استخدم 6 أحرف على الأقل.');
    const u: LocalUser = { id: uid(), email: email.trim().toLowerCase(), full_name: fullName, role: 'admin', teacher_id: null, pass: await hash(password) };
    write({ ...db, users: [...db.users, u] });
    try { localStorage.setItem(SESSION_KEY, u.id); } catch { /* تجاهل */ }
    return strip(u);
  },
  async signIn(email, password) {
    const p = await hash(password);
    const u = read().users.find((x) => x.email === email.trim().toLowerCase() && x.pass === p);
    if (!u) throw new AppError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
    try { localStorage.setItem(SESSION_KEY, u.id); } catch { /* تجاهل */ }
    return strip(u);
  },
  async signOut() { try { localStorage.removeItem(SESSION_KEY); } catch { /* تجاهل */ } },

  async loadAll() {
    const { users: _u, ...data } = read();
    const me = await this.getSession();
    // حساب المعلم يرى زياراته وخطته فقط، كما تفعل صلاحيات قاعدة البيانات
    if (me?.role === 'teacher') {
      return {
        ...data,
        teachers: data.teachers.filter((t) => t.id === me.teacher_id),
        visits: data.visits.filter((v) => v.teacher_id === me.teacher_id),
        schedule: data.schedule.filter((s) => s.teacher_id === me.teacher_id),
      };
    }
    return JSON.parse(JSON.stringify(data)) as AppData;
  },

  async saveVisit(v) {
    const db = read();
    if (db.visits.some((x) => x.id !== v.id && x.teacher_id === v.teacher_id && x.visit_number === v.visit_number)) {
      throw new AppError('هذه الزيارة مسجلة مسبقاً لهذا المعلم. لا يمكن تسجيل رقم الزيارة نفسه مرتين.');
    }
    const prev = db.visits.find((x) => x.id === v.id);
    write({ ...db, visits: upsert(db.visits, { ...v, created_at: prev?.created_at ?? new Date().toISOString() }, (x) => x.id) });
  },
  async deleteVisit(id) { const db = read(); write({ ...db, visits: db.visits.filter((v) => v.id !== id) }); },
  async setReflection(visitId, text) {
    const db = read();
    const me = await this.getSession();
    const v = db.visits.find((x) => x.id === visitId);
    if (!v || (me?.role === 'teacher' && v.teacher_id !== me.teacher_id)) throw new AppError('غير مصرح بتعديل هذه الزيارة');
    write({ ...db, visits: db.visits.map((x) => (x.id === visitId ? { ...x, teacher_reflection: text } : x)) });
  },

  async saveTeacher(t) { const db = read(); uniqueName(db.teachers, t); write({ ...db, teachers: upsert(db.teachers, t, (x) => x.id) }); },
  async deleteTeacher(id) {
    const db = read();
    if (db.visits.some((v) => v.teacher_id === id)) throw new AppError('لا يمكن حذف معلم له زيارات مسجلة. يمكنك إيقافه بدلاً من ذلك.');
    write({ ...db, teachers: db.teachers.filter((t) => t.id !== id), schedule: db.schedule.filter((s) => s.teacher_id !== id), users: db.users.map((u) => (u.teacher_id === id ? { ...u, teacher_id: null } : u)) });
  },
  async saveSubject(s) { const db = read(); uniqueName(db.subjects, s); write({ ...db, subjects: upsert(db.subjects, s, (x) => x.id) }); },
  async deleteSubject(id) {
    const db = read();
    write({ ...db, subjects: db.subjects.filter((s) => s.id !== id), teachers: db.teachers.map((t) => (t.subject_id === id ? { ...t, subject_id: null } : t)), visits: db.visits.map((v) => (v.subject_id === id ? { ...v, subject_id: null } : v)) });
  },
  async saveClass(c) { const db = read(); uniqueName(db.classes, c); write({ ...db, classes: upsert(db.classes, c, (x) => x.id) }); },
  async deleteClass(id) {
    const db = read();
    write({
      ...db, classes: db.classes.filter((c) => c.id !== id),
      visits: db.visits.map((v) => (v.class_id === id ? { ...v, class_id: null } : v)),
      schedule: db.schedule.map((s) => ({ ...s, v1_class_id: s.v1_class_id === id ? null : s.v1_class_id, v2_class_id: s.v2_class_id === id ? null : s.v2_class_id })),
    });
  },
  async saveCriterion(c) { const db = read(); write({ ...db, criteria: upsert(db.criteria, c, (x) => x.id) }); },
  async saveSettings(s) { write({ ...read(), settings: s }); },
  async saveSchedule(row) { const db = read(); write({ ...db, schedule: upsert(db.schedule, row, (x) => x.teacher_id) }); },

  async listUsers() { return { users: read().users.map(strip), invites: [] as Invite[] }; },
  async createUser(u) {
    const db = read();
    const email = u.email.trim().toLowerCase();
    if (db.users.some((x) => x.email === email)) throw new AppError('هذا البريد الإلكتروني مسجل مسبقاً.');
    if (u.password.length < 6) throw new AppError('كلمة المرور قصيرة. استخدم 6 أحرف على الأقل.');
    write({ ...db, users: [...db.users, { id: uid(), email, full_name: u.full_name, role: u.role, teacher_id: u.teacher_id, pass: await hash(u.password) }] });
  },
  async updateUser(id, patch) { const db = read(); write({ ...db, users: db.users.map((u) => (u.id === id ? { ...u, ...patch } : u)) }); },
  async deleteUser(id) { const db = read(); write({ ...db, users: db.users.filter((u) => u.id !== id) }); },
};
