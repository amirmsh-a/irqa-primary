import type { AppData, ClassRoom, Criterion, Invite, Profile, Role, ScheduleRow, Settings, Subject, Teacher, Visit } from '../lib/types';

export interface NewUser { email: string; password: string; full_name: string; role: Role; teacher_id: string | null }

/** واجهة موحدة للبيانات: تنفّذها قاعدة Supabase، ونسخة محلية للتجربة بدون خادم */
export interface Api {
  mode: 'supabase' | 'local';
  getSession(): Promise<Profile | null>;
  /** صحيح إذا لم يُنشأ حساب مدير النظام بعد (أول تشغيل) */
  needsSetup(): Promise<boolean>;
  /** يعيد null إذا كان الحساب بحاجة لتأكيد البريد قبل الدخول */
  createAdmin(email: string, password: string, fullName: string): Promise<Profile | null>;
  signIn(email: string, password: string): Promise<Profile>;
  signOut(): Promise<void>;

  loadAll(): Promise<AppData>;
  saveVisit(v: Visit): Promise<void>;
  deleteVisit(id: string): Promise<void>;
  setReflection(visitId: string, text: string): Promise<void>;

  saveTeacher(t: Teacher): Promise<void>;
  deleteTeacher(id: string): Promise<void>;
  saveSubject(s: Subject): Promise<void>;
  deleteSubject(id: string): Promise<void>;
  saveClass(c: ClassRoom): Promise<void>;
  deleteClass(id: string): Promise<void>;
  saveCriterion(c: Criterion): Promise<void>;
  saveSettings(s: Settings): Promise<void>;
  saveSchedule(row: ScheduleRow): Promise<void>;

  listUsers(): Promise<{ users: Profile[]; invites: Invite[] }>;
  createUser(u: NewUser): Promise<void>;
  updateUser(id: string, patch: Pick<Profile, 'full_name' | 'role' | 'teacher_id'>): Promise<void>;
  deleteUser(id: string): Promise<void>;
}

export class AppError extends Error {}

/** يحوّل أخطاء قاعدة البيانات والمصادقة إلى رسائل عربية واضحة */
export function arabicError(e: unknown): string {
  if (e instanceof AppError) return e.message;
  const err = e as { code?: string; message?: string; status?: number } | null;
  const msg = String(err?.message ?? e ?? '');
  const code = err?.code ?? '';
  if (code === '23505' && /visits_teacher_visit_unique/.test(msg)) return 'هذه الزيارة مسجلة مسبقاً لهذا المعلم. لا يمكن تسجيل رقم الزيارة نفسه مرتين.';
  if (code === '23505') return 'هذه القيمة موجودة مسبقاً.';
  if (code === '23503') return 'لا يمكن الحذف لوجود زيارات أو بيانات مرتبطة بهذا العنصر.';
  if (code === '42501' || /row-level security|permission denied/i.test(msg)) return 'ليست لديك صلاحية لتنفيذ هذا الإجراء.';
  if (/Invalid login credentials/i.test(msg)) return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
  if (/Email not confirmed/i.test(msg)) return 'لم يتم تأكيد البريد الإلكتروني بعد. افتح رسالة التأكيد ثم سجّل الدخول.';
  if (/already registered|already been registered/i.test(msg)) return 'هذا البريد الإلكتروني مسجل مسبقاً.';
  if (/Password should be at least/i.test(msg)) return 'كلمة المرور قصيرة. استخدم 6 أحرف على الأقل.';
  if (/valid email|invalid format/i.test(msg)) return 'صيغة البريد الإلكتروني غير صحيحة.';
  if (/Failed to fetch|NetworkError|network/i.test(msg)) return 'تعذر الاتصال بالخادم. تحقق من الإنترنت ثم أعد المحاولة.';
  if (/[؀-ۿ]/.test(msg)) return msg;
  return 'حدث خطأ غير متوقع' + (msg ? `: ${msg}` : '.');
}
