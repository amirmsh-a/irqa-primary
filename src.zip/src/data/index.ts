import type { Api } from './api';
import { localApi } from './localApi';
import { createSupabaseApi } from './supabaseApi';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const configured = !!url && !!key && !url.includes('YOUR-PROJECT');

/** إذا ضُبطت بيانات Supabase في .env يعمل الموقع على قاعدة البيانات، وإلا يعمل بالنسخة المحلية التجريبية */
export const api: Api = configured ? createSupabaseApi(url!, key!) : localApi;
