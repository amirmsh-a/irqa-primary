import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { AppData, Invite, Profile, ScheduleRow, Visit } from '../lib/types';
import { AppError, type Api } from './api';

const num = (v: unknown) => (v == null ? null : Number(v));

function ok<T>(res: { data: T; error: unknown }): T {
  if (res.error) throw res.error;
  return res.data;
}

export function createSupabaseApi(url: string, anonKey: string): Api {
  const sb: SupabaseClient = createClient(url, anonKey);

  async function profileOf(userId: string): Promise<Profile | null> {
    const row = ok(await sb.from('profiles').select('id,email,full_name,role,teacher_id').eq('id', userId).maybeSingle());
    return (row as Profile | null) ?? null;
  }

  return {
    mode: 'supabase',

    async getSession() {
      const { data } = await sb.auth.getSession();
      if (!data.session) return null;
      return profileOf(data.session.user.id);
    },
    async needsSetup() {
      const hasAdmin = ok(await sb.rpc('has_admin'));
      return !hasAdmin;
    },
    async createAdmin(email, password, fullName) {
      const res = await sb.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
      if (res.error) throw res.error;
      if (!res.data.session || !res.data.user) return null; // بانتظار تأكيد البريد
      return profileOf(res.data.user.id);
    },
    async signIn(email, password) {
      const res = await sb.auth.signInWithPassword({ email, password });
      if (res.error) throw res.error;
      const p = await profileOf(res.data.user.id);
      if (!p) {
        await sb.auth.signOut();
        throw new AppError('هذا الحساب غير مفعّل في النظام. اطلب من مدير النظام إضافتك.');
      }
      return p;
    },
    async signOut() { await sb.auth.signOut(); },

    async loadAll(): Promise<AppData> {
      const [settings, subjects, classes, teachers, criteria, visits, schedule] = await Promise.all([
        sb.from('settings').select('school,year,observer').maybeSingle(),
        sb.from('subjects').select('id,name,sort_order').order('sort_order'),
        sb.from('classes').select('id,grade,section,name,sort_order').order('sort_order'),
        sb.from('teachers').select('id,name,subject_id,active').order('name'),
        sb.from('criteria').select('id,domain,sort_order,letter,title,description,weight').order('domain').order('sort_order'),
        sb.from('visits').select('id,teacher_id,visit_number,visit_date,subject_id,class_id,period,observer_name,observer_feedback,teacher_reflection,created_at,visit_scores(criterion_id,score,weight)').order('visit_date', { ascending: false }),
        sb.from('schedule').select('*'),
      ]);
      type VisitRow = Omit<Visit, 'scores'> & { visit_scores: { criterion_id: string; score: number; weight: number | string }[] };
      return {
        settings: (ok(settings) as AppData['settings'] | null) ?? { school: '', year: '', observer: '' },
        subjects: (ok(subjects) ?? []) as AppData['subjects'],
        classes: (ok(classes) ?? []) as AppData['classes'],
        teachers: (ok(teachers) ?? []) as AppData['teachers'],
        criteria: ((ok(criteria) ?? []) as AppData['criteria']).map((c) => ({ ...c, weight: Number(c.weight) })),
        visits: ((ok(visits) ?? []) as unknown as VisitRow[]).map(({ visit_scores, ...v }) => ({
          ...v,
          scores: (visit_scores ?? []).map((s) => ({ criterion_id: s.criterion_id, score: Number(s.score), weight: Number(s.weight) })),
        })) as Visit[],
        schedule: ((ok(schedule) ?? []) as ScheduleRow[]).map((s) => ({ ...s, v1_period: num(s.v1_period), v2_period: num(s.v2_period) })),
      };
    },

    async saveVisit(v) {
      ok(await sb.rpc('save_visit', {
        p: {
          id: v.id, teacher_id: v.teacher_id, visit_number: v.visit_number, visit_date: v.visit_date,
          subject_id: v.subject_id ?? '', class_id: v.class_id ?? '', period: v.period == null ? '' : String(v.period),
          observer_name: v.observer_name, observer_feedback: v.observer_feedback, teacher_reflection: v.teacher_reflection,
          scores: v.scores,
        },
      }));
    },
    async deleteVisit(id) { ok(await sb.from('visits').delete().eq('id', id)); },
    async setReflection(visitId, text) { ok(await sb.rpc('set_teacher_reflection', { p_visit: visitId, p_text: text })); },

    async saveTeacher(t) { ok(await sb.from('teachers').upsert({ id: t.id, name: t.name, subject_id: t.subject_id, active: t.active })); },
    async deleteTeacher(id) { ok(await sb.from('teachers').delete().eq('id', id)); },
    async saveSubject(s) { ok(await sb.from('subjects').upsert(s)); },
    async deleteSubject(id) { ok(await sb.from('subjects').delete().eq('id', id)); },
    async saveClass(c) { ok(await sb.from('classes').upsert(c)); },
    async deleteClass(id) { ok(await sb.from('classes').delete().eq('id', id)); },
    async saveCriterion(c) {
      ok(await sb.from('criteria').update({ title: c.title, description: c.description, weight: c.weight, letter: c.letter }).eq('id', c.id));
    },
    async saveSettings(s) { ok(await sb.from('settings').upsert({ id: 1, ...s })); },
    async saveSchedule(row) { ok(await sb.from('schedule').upsert(row)); },

    async listUsers() {
      const [users, invites] = await Promise.all([
        sb.from('profiles').select('id,email,full_name,role,teacher_id').order('created_at'),
        sb.from('user_invites').select('email,full_name,role,teacher_id'),
      ]);
      return { users: (ok(users) ?? []) as Profile[], invites: (ok(invites) ?? []) as Invite[] };
    },
    async createUser(u) {
      const email = u.email.trim().toLowerCase();
      // 1) المدير يسجل الدعوة (البريد والدور)، 2) يُنشأ الحساب بعميل مستقل حتى لا تتغير جلسة المدير
      ok(await sb.from('user_invites').upsert({ email, full_name: u.full_name, role: u.role, teacher_id: u.teacher_id }));
      const temp = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, storageKey: 'ziyarat-signup' } });
      const res = await temp.auth.signUp({ email, password: u.password, options: { data: { full_name: u.full_name } } });
      if (res.error) {
        await sb.from('user_invites').delete().eq('email', email);
        throw res.error;
      }
    },
    async updateUser(id, patch) { ok(await sb.from('profiles').update(patch).eq('id', id)); },
    async deleteUser(id) { ok(await sb.from('profiles').delete().eq('id', id)); },
  };
}
