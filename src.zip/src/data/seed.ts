import seed from '../lib/seed-data.json';
import type { AppData, ClassRoom, Criterion, ScheduleRow, Subject, Teacher } from '../lib/types';
import { uid } from '../lib/util';

/** البيانات الأولية للنسخة المحلية (نفس محتوى supabase/02_seed.sql) */
export function buildSeed(): AppData {
  const subjects: Subject[] = seed.subjects.map((name, i) => ({ id: uid(), name, sort_order: i + 1 }));
  const classes: ClassRoom[] = [];
  (seed.grades as [string, number][]).forEach(([grade, n]) => {
    for (let i = 0; i < n; i++) {
      const section = seed.sections[i];
      classes.push({ id: uid(), grade, section, name: `${grade} ${section}`, sort_order: classes.length + 1 });
    }
  });
  const order: Record<number, number> = {};
  const criteria: Criterion[] = (seed.criteria as [number, string, string, number, string][]).map(([domain, letter, title, weight, description]) => {
    order[domain] = (order[domain] ?? 0) + 1;
    return { id: uid(), domain: domain as 1 | 2 | 3, sort_order: order[domain], letter, title, description, weight };
  });
  const ts = seed.teacherSubjects as Record<string, string>;
  const teachers: Teacher[] = seed.teachers.map((name) => ({
    id: uid(), name, active: true,
    subject_id: subjects.find((s) => s.name === ts[name])?.id ?? null,
  }));
  const schedule: ScheduleRow[] = (seed.schedule as string[][]).flatMap(([name, specialty, w1, d1, w2, d2]) => {
    const t = teachers.find((x) => x.name === name);
    return t ? [{ teacher_id: t.id, specialty, status: 'في الموعد' as const, v1_week: w1, v1_date: d1, v1_period: null, v1_class_id: null, v2_week: w2, v2_date: d2, v2_period: null, v2_class_id: null }] : [];
  });
  return { settings: { ...seed.settings }, subjects, classes, teachers, criteria, visits: [], schedule };
}
