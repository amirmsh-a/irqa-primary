import { useEffect, useState, type AnchorHTMLAttributes } from 'react';

/** موجّه بسيط يعتمد على # ليعمل الموقع على أي استضافة ثابتة دون إعدادات */
const current = () => (location.hash.replace(/^#/, '') || '/');

export function navigate(path: string) {
  if (current() === path) return;
  location.hash = path;
}

export function usePath(): string {
  const [path, setPath] = useState(current);
  useEffect(() => {
    const on = () => { setPath(current()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return path;
}

/** يطابق مساراً مثل /teachers/:id ويعيد المتغيرات أو null */
export function match(pattern: string, path: string): Record<string, string> | null {
  const [clean] = path.split('?');
  const a = pattern.split('/').filter(Boolean);
  const b = clean.split('/').filter(Boolean);
  if (a.length !== b.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

export function query(path: string): URLSearchParams {
  return new URLSearchParams(path.split('?')[1] ?? '');
}

export function Link({ to, ...rest }: { to: string } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return <a href={`#${to}`} {...rest} />;
}
