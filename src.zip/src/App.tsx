import Layout from './components/Layout';
import { match, usePath } from './router';
import { useStore } from './store';
import { cx } from './lib/util';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import VisitForm from './pages/VisitForm';
import VisitLog from './pages/VisitLog';
import Teachers from './pages/Teachers';
import TeacherProfile from './pages/TeacherProfile';
import VisitView from './pages/VisitView';
import Schedule from './pages/Schedule';
import SettingsPage from './pages/Settings';
import DataPage from './pages/DataPage';
import { Empty } from './components/ui';
import { Link } from './router';

function Toasts() {
  const { toasts, dismiss } = useStore();
  return (
    <div className="fixed z-[60] top-3 inset-x-0 flex flex-col items-center gap-2 px-3 pointer-events-none no-print" aria-live="polite">
      {toasts.map((t) => (
        <button key={t.id} type="button" onClick={() => dismiss(t.id)}
          className={cx('pointer-events-auto max-w-md w-full text-right rounded-xl px-4 py-3 shadow-lg border font-medium cursor-pointer',
            t.kind === 'ok' && 'bg-good-soft text-good border-good/30',
            t.kind === 'error' && 'bg-bad-soft text-bad border-bad/30',
            t.kind === 'info' && 'bg-surface text-ink border-line')}>
          {t.text}
        </button>
      ))}
    </div>
  );
}

function Routes({ path }: { path: string }) {
  const { isStaff, user } = useStore();
  let m: Record<string, string> | null;

  if (!isStaff) {
    // حساب المعلم: زياراته فقط
    if ((m = match('/visits/:id', path))) return <VisitView id={m.id} />;
    if (!user?.teacher_id) return <Empty title="حسابك غير مربوط بمعلم">اطلب من مدير النظام ربط حسابك باسمك في قائمة المعلمين.</Empty>;
    return <TeacherProfile id={user.teacher_id} own />;
  }

  if (match('/', path)) return <Dashboard />;
  if (match('/visits/new', path)) return <VisitForm key="new" />;
  if ((m = match('/visits/:id/edit', path))) return <VisitForm key={m.id} editId={m.id} />;
  if ((m = match('/visits/:id', path))) return <VisitView id={m.id} />;
  if (match('/log', path)) return <VisitLog />;
  if (match('/teachers', path)) return <Teachers />;
  if ((m = match('/teachers/:id', path))) return <TeacherProfile id={m.id} />;
  if (match('/schedule', path)) return <Schedule />;
  if (match('/settings', path)) return <SettingsPage />;
  if (match('/data', path)) return <DataPage />;
  return <Empty title="الصفحة غير موجودة"><Link to="/" className="text-brand underline">العودة إلى لوحة المعلومات</Link></Empty>;
}

export default function App() {
  const { user, data, booting } = useStore();
  const path = usePath();
  return (
    <>
      <Toasts />
      {booting ? (
        <div className="min-h-screen grid place-items-center text-muted">جارٍ التحميل…</div>
      ) : !user ? (
        <Login />
      ) : !data ? (
        <div className="min-h-screen grid place-items-center text-muted">جارٍ تحميل البيانات…</div>
      ) : (
        <Layout path={path}><Routes path={path} /></Layout>
      )}
    </>
  );
}
