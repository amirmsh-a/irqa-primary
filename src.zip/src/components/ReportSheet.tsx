import { scoreOf, visitTotals, fmt } from '../lib/calc';
import { DOMAINS, SCALE, type Visit } from '../lib/types';
import { gregorian, hijri } from '../lib/util';
import { useData } from '../store';

/** تقرير الزيارة بصيغة A4 مطابق لنموذج «أداة معارف للملاحظة الصفية» */
export default function ReportSheet({ visit, variant }: { visit: Visit; variant: 'full' | 'short' }) {
  const d = useData();
  const t = visitTotals(visit, d.criteria);
  const teacher = d.teacherName(visit.teacher_id);
  const observer = visit.observer_name || d.settings.observer;

  const head = (
    <>
      <h1 style={{ textAlign: 'center', fontSize: '15pt', fontWeight: 700, margin: '0 0 6pt' }}>أداة معارف للملاحظة الصفية</h1>
      <table style={{ marginBottom: '6pt' }}>
        <tbody>
          <tr>
            <th style={{ width: '14%' }}>المدرسة</th><td style={{ width: '40%' }}>{d.settings.school}</td>
            <th style={{ width: '12%' }}>التاريخ</th><td>{gregorian(visit.visit_date)}م — {hijri(visit.visit_date)}</td>
          </tr>
          <tr>
            <th>العام الدراسي</th><td>{d.settings.year}</td>
            <th>المادة</th><td>{d.subjectName(visit.subject_id)}</td>
          </tr>
          <tr>
            <th>الملاحظ</th><td>{observer}</td>
            <th>الصف</th><td>{d.className(visit.class_id)}{visit.period ? ` — الحصة ${visit.period}` : ''}</td>
          </tr>
          <tr>
            <th>اسم المعلم</th><td style={{ fontWeight: 700 }}>{teacher}</td>
            <th>رقم الزيارة</th><td>الزيارة {visit.visit_number}</td>
          </tr>
        </tbody>
      </table>
    </>
  );

  const totalsTable = (
    <table className="avoid-break" style={{ marginBottom: '8pt' }}>
      <thead>
        <tr><th style={{ textAlign: 'right' }}>المجال</th><th style={{ width: '22%' }}>مجموع الدرجات</th><th style={{ width: '22%' }}>مجموع الوزن</th></tr>
      </thead>
      <tbody>
        {DOMAINS.map((dom) => (
          <tr key={dom.id}>
            <td>مجموع {dom.name}</td>
            <td style={{ textAlign: 'center' }}>{t.domains[dom.id].raw} / {t.domains[dom.id].maxRaw}</td>
            <td style={{ textAlign: 'center' }}>{fmt(t.domains[dom.id].weighted)} / {fmt(t.domains[dom.id].maxWeighted)}</td>
          </tr>
        ))}
        <tr className="grand-row">
          <td>الإجمالي العام / النسبة الموزونة</td>
          <td style={{ textAlign: 'center' }}>{t.raw} / {t.maxRaw}</td>
          <td style={{ textAlign: 'center' }}>{fmt(t.pct)}%</td>
        </tr>
      </tbody>
    </table>
  );

  const notes = (
    <>
      <div className="avoid-break" style={{ marginBottom: '8pt' }}>
        <p style={{ fontWeight: 700, margin: '0 0 3pt' }}>التغذية الراجعة ومرئيات الملاحظ</p>
        <div className="box" style={{ minHeight: variant === 'full' ? '55mm' : '34mm' }}>{visit.observer_feedback}</div>
      </div>
      <div className="avoid-break" style={{ marginBottom: '10pt' }}>
        <p style={{ fontWeight: 700, margin: '0 0 3pt' }}>تأملات المعلم ومرئياته وخطط التحسين</p>
        <div className="box" style={{ minHeight: variant === 'full' ? '55mm' : '34mm' }}>{visit.teacher_reflection}</div>
      </div>
      <table className="avoid-break">
        <tbody>
          <tr><th style={{ width: '12%' }}>المعلم</th><td style={{ width: '48%' }}>{teacher}</td><th style={{ width: '12%' }}>التوقيع</th><td style={{ height: '13mm' }} /></tr>
          <tr><th>الملاحظ</th><td>{observer}</td><th>التوقيع</th><td style={{ height: '13mm' }} /></tr>
        </tbody>
      </table>
    </>
  );

  if (variant === 'short') {
    return <div className="sheet" dir="rtl">{head}{totalsTable}{notes}</div>;
  }

  return (
    <>
      <div className="sheet" dir="rtl">
        {head}
        <table className="criteria-table">
          <thead>
            <tr>
              <th colSpan={2} style={{ width: '20%' }}>المجال العام والمعايير</th>
              <th>تفاصيل المجال والمعايير</th>
              <th style={{ width: '4.5%' }}>الوزن</th>
              {SCALE.map((s) => <th key={s.value} style={{ width: '4.7%', fontSize: '6pt' }}>{s.label}</th>)}
              <th style={{ width: '5.5%', fontSize: '6pt' }}>الدرجة المستحقة</th>
              <th style={{ width: '5.5%', fontSize: '6pt' }}>الوزن النسبي</th>
            </tr>
          </thead>
          <tbody>
            {DOMAINS.map((dom) => (
              <DomainRows key={dom.id} visit={visit} domain={dom} />
            ))}
            <tr className="grand-row">
              <td colSpan={9} style={{ textAlign: 'left' }}>الإجمالي العام / النسبة الموزونة</td>
              <td style={{ textAlign: 'center' }}>{t.raw}</td>
              <td style={{ textAlign: 'center' }}>{fmt(t.pct)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="sheet sheet-gap" dir="rtl">
        {head}{totalsTable}{notes}
      </div>
    </>
  );
}

function DomainRows({ visit, domain }: { visit: Visit; domain: { id: 1 | 2 | 3; name: string } }) {
  const d = useData();
  const t = visitTotals(visit, d.criteria).domains[domain.id];
  return (
    <>
      <tr className="domain-row"><td style={{ textAlign: 'center', width: '3.5%' }}>{domain.id}</td><td colSpan={10}>{domain.name}</td></tr>
      {d.criteria.filter((c) => c.domain === domain.id).map((c) => {
        const s = scoreOf(visit, c.id);
        return (
          <tr key={c.id}>
            <td style={{ textAlign: 'center' }}>{c.letter}</td>
            <td style={{ fontWeight: 600 }}>{c.title}</td>
            <td>{c.description}</td>
            <td style={{ textAlign: 'center' }}>{fmt(s?.weight ?? c.weight)}</td>
            {SCALE.map((sc) => (
              <td key={sc.value} className="mark" style={{ textAlign: 'center', background: s?.score === sc.value ? '#0f4c5c' : undefined, color: s?.score === sc.value ? '#fff' : '#999', WebkitPrintColorAdjust: 'exact', printColorAdjust: 'exact' }}>
                {sc.value}
              </td>
            ))}
            <td style={{ textAlign: 'center', fontWeight: 700 }}>{s ? s.score : ''}</td>
            <td style={{ textAlign: 'center', fontWeight: 700 }}>{s ? fmt(s.score * s.weight) : ''}</td>
          </tr>
        );
      })}
      <tr className="total-row">
        <td colSpan={9} style={{ textAlign: 'left' }}>المجموع</td>
        <td style={{ textAlign: 'center' }}>{t.raw}</td>
        <td style={{ textAlign: 'center' }}>{fmt(t.weighted)}</td>
      </tr>
    </>
  );
}
