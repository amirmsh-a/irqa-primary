import { useEffect, useMemo, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { cx, norm } from '../lib/util';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
const variants: Record<Variant, string> = {
  primary: 'bg-brand text-on-brand hover:opacity-90',
  secondary: 'bg-surface text-ink border border-line hover:bg-sunken',
  ghost: 'text-brand hover:bg-brand-soft',
  danger: 'bg-bad text-white dark:text-black hover:opacity-90',
};

export function Button({ variant = 'secondary', small, className, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; small?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap',
        small ? 'px-3 py-1.5 text-sm min-h-9' : 'px-4 py-2 min-h-11',
        variants[variant], className,
      )}
    />
  );
}

export const inputCls = 'w-full rounded-lg border border-line bg-surface text-ink px-3 py-2 min-h-11 placeholder:text-muted focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/25';

export function Field({ label, hint, children, className }: { label: string; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={cx('block', className)}>
      <span className="block text-sm font-medium text-muted mb-1">{label}</span>
      {children}
      {hint && <span className="block text-xs text-muted mt-1">{hint}</span>}
    </label>
  );
}
export const Input = ({ className, ...p }: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx(inputCls, className)} />;
export const Select = ({ className, ...p }: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cx(inputCls, className)} />;
export const Textarea = ({ className, ...p }: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cx(inputCls, 'min-h-28 leading-7', className)} />;

export function Card({ title, actions, children, className }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cx('bg-surface border border-line rounded-xl', className)}>
      {(title || actions) && (
        <header className="flex items-center justify-between gap-3 px-4 pt-4">
          <h2 className="font-semibold text-lg">{title}</h2>
          {actions}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function PageHeader({ title, sub, actions }: { title: string; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 mb-5 no-print">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        {sub && <p className="text-muted mt-1">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Badge({ tone = 'neutral', children }: { tone?: 'neutral' | 'good' | 'bad' | 'warn' | 'brand'; children: ReactNode }) {
  const tones = {
    neutral: 'bg-sunken text-muted', good: 'bg-good-soft text-good', bad: 'bg-bad-soft text-bad',
    warn: 'bg-warn-soft text-warn', brand: 'bg-brand-soft text-brand',
  };
  return <span className={cx('inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium whitespace-nowrap', tones[tone])}>{children}</span>;
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="text-center py-10 px-4">
      <p className="font-semibold">{title}</p>
      {children && <div className="text-muted mt-2 text-sm">{children}</div>}
    </div>
  );
}

export function Modal({ title, onClose, children, footer, wide }: { title: string; onClose(): void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 no-print" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={cx('bg-surface w-full rounded-t-2xl sm:rounded-2xl border border-line max-h-[92vh] flex flex-col', wide ? 'sm:max-w-3xl' : 'sm:max-w-lg')}>
        <header className="flex items-center justify-between px-5 py-4 border-b border-line">
          <h2 className="font-semibold text-lg">{title}</h2>
          <button type="button" onClick={onClose} aria-label="إغلاق" className="text-muted hover:text-ink text-2xl leading-none px-2 cursor-pointer">×</button>
        </header>
        <div className="p-5 overflow-y-auto">{children}</div>
        {footer && <footer className="flex flex-wrap justify-end gap-2 px-5 py-4 border-t border-line">{footer}</footer>}
      </div>
    </div>
  );
}

export function Confirm({ title, text, confirmLabel, onConfirm, onClose }: { title: string; text: ReactNode; confirmLabel: string; onConfirm(): void; onClose(): void }) {
  return (
    <Modal title={title} onClose={onClose} footer={<><Button onClick={onClose}>إلغاء</Button><Button variant="danger" onClick={() => { onConfirm(); onClose(); }}>{confirmLabel}</Button></>}>
      <div className="leading-7">{text}</div>
    </Modal>
  );
}

/** قائمة منسدلة قابلة للبحث (تتجاهل الفروق بين أ/ا وة/ه) */
export function Combobox({ options, value, onChange, placeholder, disabled }: {
  options: { id: string; label: string; hint?: string }[]; value: string; onChange(id: string): void; placeholder?: string; disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const selected = options.find((o) => o.id === value);
  const list = useMemo(() => {
    const n = norm(q);
    return n ? options.filter((o) => norm(o.label).includes(n)) : options;
  }, [options, q]);

  useEffect(() => {
    const on = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', on);
    return () => document.removeEventListener('mousedown', on);
  }, []);

  const pick = (id: string) => { onChange(id); setOpen(false); setQ(''); };

  return (
    <div className="relative" ref={box}>
      <input
        role="combobox" aria-expanded={open} aria-autocomplete="list" disabled={disabled}
        className={inputCls}
        placeholder={placeholder}
        value={open ? q : selected?.label ?? ''}
        onFocus={() => { setOpen(true); setQ(''); setActive(0); }}
        onChange={(e) => { setQ(e.target.value); setOpen(true); setActive(0); }}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, list.length - 1)); }
          else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
          else if (e.key === 'Enter' && open && list[active]) { e.preventDefault(); pick(list[active].id); }
          else if (e.key === 'Escape') setOpen(false);
        }}
      />
      {open && (
        <ul role="listbox" className="absolute z-30 mt-1 w-full max-h-64 overflow-y-auto bg-surface border border-line rounded-lg shadow-lg">
          {list.length === 0 && <li className="px-3 py-3 text-muted text-sm">لا توجد نتائج مطابقة</li>}
          {list.map((o, i) => (
            <li
              key={o.id} role="option" aria-selected={o.id === value}
              onMouseDown={(e) => { e.preventDefault(); pick(o.id); }}
              onMouseEnter={() => setActive(i)}
              className={cx('px-3 py-2.5 cursor-pointer flex items-center justify-between gap-2', i === active && 'bg-brand-soft', o.id === value && 'font-semibold')}
            >
              <span>{o.label}</span>
              {o.hint && <span className="text-xs text-muted">{o.hint}</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** شريط نسبة أفقي بسيط */
export function Meter({ pct, tone = 'brand' }: { pct: number; tone?: 'brand' | 'good' | 'bad' }) {
  const bg = tone === 'good' ? 'bg-good' : tone === 'bad' ? 'bg-bad' : 'bg-brand';
  return (
    <div className="h-2 rounded-full bg-sunken overflow-hidden" role="img" aria-label={`${pct}%`}>
      <div className={cx('h-full rounded-full', bg)} style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} />
    </div>
  );
}
