import type { ReactNode } from 'react';
import { api } from '../data';
import { Link, navigate } from '../router';
import { useStore } from '../store';
import { cx } from '../lib/util';

const icons: Record<string, string> = {
  home: 'M3 11.5 12 4l9 7.5M5.5 10v9.5h13V10',
  plus: 'M12 5v14M5 12h14',
  table: 'M4 5h16v14H4zM4 10h16M4 15h16M10 5v14',
  users: 'M16 19v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 17.5V19M10 10.5a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5M20 19v-1.5a3.5 3.5 0 0 0-2.5-3.35M15 4.2a3.25 3.25 0 0 1 0 6.1',
  calendar: 'M5 6h14v14H5zM5 10h14M9 4v4M15 4v4',
  swap: 'M7 4v14m0 0-3-3m3 3 3-3M17 20V6m0 0-3 3m3-3 3 3',
  cog: 'M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2.1-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2.1 1.2l-2.3-.9-2 3.4 2 1.5a7 7 0 0 0 0 2.4l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2.1 1.2L10 21h4l.5-2.6a7 7 0 0 0 2.1-1.2l2.3.9 2-3.4-2-1.5c.07-.4.1-.8.1-1.2',
  doc: 'M7 3h7l4 4v14H7zM14 3v4h4M10 12h5M10 16h5',
};
export function Icon({ name, className }: { name: string; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cx('w-5 h-5 shrink-0', className)} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={icons[name]} />
    </svg>
  );
}

const staffNav = [
  { to: '/', label: 'لوحة المعلومات', short: 'اللوحة', icon: 'home' },
  { to: '/visits/new', label: 'زيارة جديدة', short: 'زيارة', icon: 'plus' },
  { to: '/log', label: 'سجل التقييم', short: 'السجل', icon: 'table' },
  { to: '/teachers', label: 'المعلمون', short: 'المعلمون', icon: 'users' },
  { to: '/schedule', label: 'خطة الزيارات', short: 'الخطة', icon: 'calendar' },
  { to: '/data', label: 'الاستيراد والتصدير', short: 'البيانات', icon: 'swap', desktopOnly: true },
  { to: '/settings', label: 'الإعدادات', short: 'الإعدادات', icon: 'cog', desktopOnly: true },
];
const teacherNav = [{ to: '/my', label: 'زياراتي', short: 'زياراتي', icon: 'doc' }];

const roleLabel = { admin: 'مدير النظام', observer: 'ملاحظ', teacher: 'معلم' } as const;

export default function Layout({ path, children }: { path: string; children: ReactNode }) {
  const { user, setUser, theme, toggleTheme, isStaff, data } = useStore();
  const nav = isStaff ? staffNav : teacherNav;
  const active = (to: string) => (to === '/' ? path === '/' : path.startsWith(to));
  const signOut = async () => { await api.signOut(); setUser(null); navigate('/'); };

  return (
    <div className="min-h-screen lg:flex print-root">
      {/* الشريط الجانبي (الشاشات الواسعة) */}
      <aside className="hidden lg:flex no-print w-64 shrink-0 flex-col bg-surface border-l border-line sticky top-0 h-screen">
        <div className="px-5 py-5 border-b border-line">
          <p className="font-bold text-lg text-brand leading-snug">الزيارات الصفية</p>
          <p className="text-xs text-muted mt-1 leading-5">{data?.settings.school}</p>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto" aria-label="القائمة الرئيسية">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} aria-current={active(n.to) ? 'page' : undefined}
              className={cx('flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium', active(n.to) ? 'bg-brand text-on-brand' : 'text-ink hover:bg-sunken')}>
              <Icon name={n.icon} />{n.label}
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-line text-sm">
          <p className="font-semibold truncate">{user?.full_name || user?.email}</p>
          <p className="text-muted text-xs mb-3">{user && roleLabel[user.role]}</p>
          <div className="flex gap-2">
            <button type="button" onClick={toggleTheme} className="flex-1 rounded-lg border border-line py-2 hover:bg-sunken cursor-pointer">{theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}</button>
            <button type="button" onClick={signOut} className="flex-1 rounded-lg border border-line py-2 hover:bg-sunken cursor-pointer">خروج</button>
          </div>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        {/* الشريط العلوي (الجوال واللوحي) */}
        <header className="lg:hidden no-print sticky top-0 z-40 bg-surface border-b border-line flex items-center justify-between px-4 py-2.5">
          <div className="min-w-0">
            <p className="font-bold text-brand">الزيارات الصفية</p>
            <p className="text-xs text-muted truncate">{user?.full_name || user?.email}</p>
          </div>
          <div className="flex gap-1.5 text-sm">
            {isStaff && <Link to="/data" className="rounded-lg border border-line px-2.5 py-2" aria-label="الاستيراد والتصدير"><Icon name="swap" /></Link>}
            {isStaff && <Link to="/settings" className="rounded-lg border border-line px-2.5 py-2" aria-label="الإعدادات"><Icon name="cog" /></Link>}
            <button type="button" onClick={toggleTheme} className="rounded-lg border border-line px-3 py-2 cursor-pointer">{theme === 'dark' ? 'فاتح' : 'داكن'}</button>
            <button type="button" onClick={signOut} className="rounded-lg border border-line px-3 py-2 cursor-pointer">خروج</button>
          </div>
        </header>

        {api.mode === 'local' && (
          <div className="no-print bg-warn-soft text-warn text-sm px-4 py-2 text-center">
            نسخة تجريبية محلية: البيانات محفوظة في هذا المتصفح فقط. اربط الموقع بـ Supabase لتُحفظ في قاعدة بيانات مشتركة.
          </div>
        )}

        <main className="px-4 sm:px-6 lg:px-8 py-6 pb-28 lg:pb-10 max-w-[1400px] mx-auto print-root">{children}</main>

        {/* شريط التنقل السفلي (الجوال) */}
        {nav.length > 1 && (
          <nav className="lg:hidden no-print fixed bottom-0 inset-x-0 z-40 bg-surface border-t border-line grid grid-cols-5 pb-[env(safe-area-inset-bottom)]" aria-label="القائمة الرئيسية">
            {nav.filter((n) => !('desktopOnly' in n && n.desktopOnly)).map((n) => (
              <Link key={n.to} to={n.to} aria-current={active(n.to) ? 'page' : undefined}
                className={cx('flex flex-col items-center gap-1 py-2 text-xs font-medium', active(n.to) ? 'text-brand' : 'text-muted')}>
                <Icon name={n.icon} />{n.short}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </div>
  );
}
