// يولّد supabase/02_seed.sql من src/lib/seed-data.json
import { readFileSync, writeFileSync } from 'node:fs';
const d = JSON.parse(readFileSync(new URL('../src/lib/seed-data.json', import.meta.url), 'utf8'));
const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
let out = `-- بيانات أولية: تُشغَّل مرة واحدة بعد 01_schema.sql (آمنة عند إعادة التشغيل)\n\n`;
out += `insert into public.settings (id, school, year, observer) values (1, ${q(d.settings.school)}, ${q(d.settings.year)}, ${q(d.settings.observer)})\n  on conflict (id) do nothing;\n\n`;
out += `insert into public.subjects (name, sort_order) values\n` + d.subjects.map((s, i) => `  (${q(s)}, ${i + 1})`).join(',\n') + `\n  on conflict (name) do nothing;\n\n`;
const classes = [];
d.grades.forEach(([g, n]) => { for (let i = 0; i < n; i++) classes.push([g, d.sections[i]]); });
out += `insert into public.classes (grade, section, name, sort_order) values\n` + classes.map(([g, s], i) => `  (${q(g)}, ${q(s)}, ${q(g + ' ' + s)}, ${i + 1})`).join(',\n') + `\n  on conflict (name) do nothing;\n\n`;
const order = {};
out += `insert into public.criteria (domain, sort_order, letter, title, weight, description) values\n` + d.criteria.map(([dom, letter, title, w, desc]) => { order[dom] = (order[dom] || 0) + 1; return `  (${dom}, ${order[dom]}, ${q(letter)}, ${q(title)}, ${w}, ${q(desc)})`; }).join(',\n') + `\n  on conflict (domain, sort_order) do nothing;\n\n`;
out += `insert into public.teachers (name, subject_id) values\n` + d.teachers.map((t) => `  (${q(t)}, ${d.teacherSubjects[t] ? `(select id from public.subjects where name = ${q(d.teacherSubjects[t])})` : 'null'})`).join(',\n') + `\n  on conflict (name) do nothing;\n\n`;
out += `-- خطة الزيارات المنقولة من ملف Excel (المعلمون المسمَّون في ورقة الخطة)\ninsert into public.schedule (teacher_id, specialty, status, v1_week, v1_date, v2_week, v2_date)\nselect t.id, x.specialty, 'في الموعد', x.w1, x.d1::date, x.w2, x.d2::date\nfrom (values\n` + d.schedule.map((r) => `  (${r.map(q).join(', ')})`).join(',\n') + `\n) as x(name, specialty, w1, d1, w2, d2)\njoin public.teachers t on t.name = x.name\non conflict (teacher_id) do nothing;\n`;
writeFileSync(new URL('../supabase/02_seed.sql', import.meta.url), out);
console.log('written 02_seed.sql');
